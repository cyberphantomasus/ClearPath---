import 'package:tflite_flutter/tflite_flutter.dart';
import 'features.dart';
import '../models/session_model.dart';

class InferenceService {
  static final InferenceService _instance = InferenceService._internal();
  factory InferenceService() => _instance;
  InferenceService._internal();

  Interpreter? _dyslexiaInterpreter;
  Interpreter? _adhdInterpreter;
  Interpreter? _autismInterpreter;
  bool _modelsLoaded = false;

  Future<void> loadModels() async {
    if (_modelsLoaded) return;
    try {
      _dyslexiaInterpreter = await Interpreter.fromAsset('assets/models/dyslexia.tflite');
      _adhdInterpreter = await Interpreter.fromAsset('assets/models/adhd.tflite');
      _autismInterpreter = await Interpreter.fromAsset('assets/models/autism.tflite');
      _modelsLoaded = true;
    } catch (e) {
      _modelsLoaded = false;
    }
  }

  Future<Map<String, double>> runInference(SessionModel session) async {
    final features = FeatureExtractor.extract(session);
    session.features = features;
    final vector = FeatureExtractor.toVector(features);

    final scores = _modelsLoaded
        ? {
            'dyslexia': _runSingleModel(_dyslexiaInterpreter!, vector),
            'adhd': _runSingleModel(_adhdInterpreter!, vector),
            'autism': _runSingleModel(_autismInterpreter!, vector),
          }
        : _heuristicFallback(features);

    session.dyslexiaRisk = scores['dyslexia']!;
    session.adhdRisk = scores['adhd']!;
    session.autismRisk = scores['autism']!;
    return scores;
  }

  double _runSingleModel(Interpreter interpreter, List<double> vector) {
    try {
      final input = [vector];
      final output = List.generate(1, (_) => List.filled(2, 0.0));
      interpreter.run(input, output);
      return (output[0][1] as double).clamp(0.0, 1.0);
    } catch (e) {
      return 0.0;
    }
  }

  Map<String, double> _heuristicFallback(Map<String, double> f) {
    return {
      'dyslexia': _clamp((f['error_pattern_score']! * 0.45) + (f['error_rate']! * 0.30) + (_norm(f['mean_response_time']!) * 0.25)),
      'adhd': _clamp((f['impulsivity_score']! * 0.30) + (_neg(f['attention_drift_index']!) * 0.25) + (f['response_time_variance']! * 0.25) + (f['engagement_decay_rate']! * 0.20)),
      'autism': _clamp(((1.0 - f['emotion_accuracy']!) * 0.45) + (_norm(f['social_hesitation_time']!) * 0.30) + ((1.0 - f['sequence_memory_score']!) * 0.25)),
    };
  }

  double _clamp(double v) => v.clamp(0.0, 1.0);
  double _norm(double ms) => _clamp((ms - 500) / 2500);
  double _neg(double d) => _clamp(d < 0 ? -d : 0.0);

  void dispose() {
    _dyslexiaInterpreter?.close();
    _adhdInterpreter?.close();
    _autismInterpreter?.close();
    _modelsLoaded = false;
  }
}
