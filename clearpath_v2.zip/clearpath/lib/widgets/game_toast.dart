import 'package:flutter/material.dart';
import '../main.dart';

/// Shows a child-friendly toast that slides up from the bottom.
/// Displays: "Fast & Correct" / "Slow & Correct" / "Wrong!" / "Time Out!"
class GameToast {
  static OverlayEntry? _current;

  static void show(
    BuildContext context, {
    required ToastType type,
    required int responseTimeMs,
  }) {
    // Remove existing toast
    _current?.remove();
    _current = null;

    final overlay = Overlay.of(context);
    late OverlayEntry entry;

    entry = OverlayEntry(
      builder: (_) => _ToastWidget(
        type: type,
        responseTimeMs: responseTimeMs,
        onDone: () {
          entry.remove();
          if (_current == entry) _current = null;
        },
      ),
    );

    _current = entry;
    overlay.insert(entry);
  }
}

enum ToastType { fastCorrect, slowCorrect, wrong, timeOut }

extension ToastTypeExtension on ToastType {
  String get emoji {
    switch (this) {
      case ToastType.fastCorrect: return '⚡';
      case ToastType.slowCorrect: return '✅';
      case ToastType.wrong: return '❌';
      case ToastType.timeOut: return '⏰';
    }
  }

  String get title {
    switch (this) {
      case ToastType.fastCorrect: return 'Fast & Correct!';
      case ToastType.slowCorrect: return 'Correct!';
      case ToastType.wrong: return 'Wrong!';
      case ToastType.timeOut: return 'Time Out!';
    }
  }

  String get subtitle {
    switch (this) {
      case ToastType.fastCorrect: return 'Amazing speed! Keep it up! 🌟';
      case ToastType.slowCorrect: return 'Good job! Try to be faster!';
      case ToastType.wrong: return 'Oops! Try again next round.';
      case ToastType.timeOut: return 'Too slow! Watch carefully next time.';
    }
  }

  Color get color {
    switch (this) {
      case ToastType.fastCorrect: return AppColors.primary;
      case ToastType.slowCorrect: return AppColors.green;
      case ToastType.wrong: return AppColors.red;
      case ToastType.timeOut: return AppColors.orange;
    }
  }

  Color get bgColor {
    switch (this) {
      case ToastType.fastCorrect: return const Color(0xFFF5F3FF);
      case ToastType.slowCorrect: return const Color(0xFFF0FDF4);
      case ToastType.wrong: return const Color(0xFFFEF2F2);
      case ToastType.timeOut: return const Color(0xFFFFF7ED);
    }
  }
}

class _ToastWidget extends StatefulWidget {
  final ToastType type;
  final int responseTimeMs;
  final VoidCallback onDone;

  const _ToastWidget({
    required this.type,
    required this.responseTimeMs,
    required this.onDone,
  });

  @override
  State<_ToastWidget> createState() => _ToastWidgetState();
}

class _ToastWidgetState extends State<_ToastWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _ctrl;
  late Animation<Offset> _slideAnim;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 350),
    );
    _slideAnim = Tween<Offset>(
      begin: const Offset(0, 1),
      end: Offset.zero,
    ).animate(CurvedAnimation(parent: _ctrl, curve: Curves.easeOutBack));

    _fadeAnim = CurvedAnimation(parent: _ctrl, curve: Curves.easeOut);

    _ctrl.forward();

    // Stay visible for 2.5 seconds then slide out
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) {
        _ctrl.reverse().then((_) => widget.onDone());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final t = widget.type;
    final speedText = widget.responseTimeMs > 0
        ? '${(widget.responseTimeMs / 1000).toStringAsFixed(2)}s'
        : '';

    return Positioned(
      bottom: 40,
      left: 20,
      right: 20,
      child: SlideTransition(
        position: _slideAnim,
        child: FadeTransition(
          opacity: _fadeAnim,
          child: Material(
            color: Colors.transparent,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
              decoration: BoxDecoration(
                color: t.bgColor,
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: t.color.withOpacity(0.3), width: 2),
                boxShadow: [
                  BoxShadow(
                    color: t.color.withOpacity(0.25),
                    blurRadius: 20,
                    offset: const Offset(0, 8),
                  ),
                ],
              ),
              child: Row(
                children: [
                  // Emoji circle
                  Container(
                    width: 52,
                    height: 52,
                    decoration: BoxDecoration(
                      color: t.color.withOpacity(0.15),
                      shape: BoxShape.circle,
                    ),
                    child: Center(
                      child: Text(t.emoji, style: const TextStyle(fontSize: 26)),
                    ),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          t.title,
                          style: TextStyle(
                            fontSize: 17,
                            fontWeight: FontWeight.w800,
                            color: t.color,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          t.subtitle,
                          style: const TextStyle(
                            fontSize: 13,
                            color: AppColors.textMid,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (speedText.isNotEmpty)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: t.color.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Text(
                        speedText,
                        style: TextStyle(
                          color: t.color,
                          fontWeight: FontWeight.w800,
                          fontSize: 13,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }
}

/// Helper to determine toast type from response time and correctness.
/// Fast = under 1500ms, Slow = over 1500ms
ToastType getToastType({required bool correct, required bool timedOut, required int responseTimeMs}) {
  if (timedOut) return ToastType.timeOut;
  if (!correct) return ToastType.wrong;
  if (responseTimeMs < 1500) return ToastType.fastCorrect;
  return ToastType.slowCorrect;
}
