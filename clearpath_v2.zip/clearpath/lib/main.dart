import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'screens/game1_screen.dart';
import 'screens/game2_screen.dart';
import 'screens/game3_screen.dart';
import 'screens/report_screen.dart';
import 'models/session_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.dark,
  ));
  runApp(const ClearPathApp());
}

class ClearPathApp extends StatelessWidget {
  const ClearPathApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ClearPath',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.bright(),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/': return _fade(const HomeScreen());
          case '/game1': return _fade(Game1Screen(session: settings.arguments as SessionModel));
          case '/game2': return _fade(Game2Screen(session: settings.arguments as SessionModel));
          case '/game3': return _fade(Game3Screen(session: settings.arguments as SessionModel));
          case '/report': return _fade(ReportScreen(session: settings.arguments as SessionModel));
          default: return _fade(const HomeScreen());
        }
      },
    );
  }
  PageRoute _fade(Widget p) => PageRouteBuilder(
    pageBuilder: (_, a, __) => p,
    transitionsBuilder: (_, anim, __, child) => FadeTransition(opacity: anim, child: child),
    transitionDuration: const Duration(milliseconds: 250),
  );
}

class AppTheme {
  static ThemeData bright() => ThemeData(
    brightness: Brightness.light,
    scaffoldBackgroundColor: AppColors.bg,
    colorScheme: const ColorScheme.light(
      primary: AppColors.primary,
      secondary: AppColors.secondary,
      surface: Colors.white,
      error: AppColors.red,
    ),
    textTheme: const TextTheme(
      displayLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.w800, color: AppColors.textDark),
      headlineMedium: TextStyle(fontSize: 22, fontWeight: FontWeight.w700, color: AppColors.textDark),
      bodyLarge: TextStyle(fontSize: 16, color: AppColors.textDark),
      bodyMedium: TextStyle(fontSize: 14, color: AppColors.textMid),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 28),
        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        elevation: 4,
      ),
    ),
    cardTheme: CardTheme(
      elevation: 6,
      shadowColor: Colors.black.withOpacity(0.08),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      color: Colors.white,
    ),
  );
}

class AppColors {
  static const bg = Color(0xFFFFF8F0);
  static const primary = Color(0xFF7C3AED);
  static const secondary = Color(0xFF06B6D4);
  static const yellow = Color(0xFFFFD60A);
  static const green = Color(0xFF22C55E);
  static const red = Color(0xFFEF4444);
  static const orange = Color(0xFFF97316);
  static const pink = Color(0xFFEC4899);
  static const textDark = Color(0xFF1E1B4B);
  static const textMid = Color(0xFF6B7280);
  static const textLight = Color(0xFFD1D5DB);
  static const cardBlue = Color(0xFFEFF6FF);
  static const cardPurple = Color(0xFFF5F3FF);
  static const cardGreen = Color(0xFFF0FDF4);
  static const cardYellow = Color(0xFFFFFBEB);
  static const cardPink = Color(0xFFFDF2F8);
  static const dyslexia = Color(0xFF7C3AED);
  static const adhd = Color(0xFFF97316);
  static const autism = Color(0xFF059669);
}
