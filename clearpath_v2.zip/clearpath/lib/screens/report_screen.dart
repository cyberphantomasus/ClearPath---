import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import '../main.dart';
import '../models/session_model.dart';
import '../services/features.dart';
import '../services/inference.dart';
import '../services/logger.dart';
import '../services/pdf_service.dart';

class ReportScreen extends StatefulWidget {
  final SessionModel session;
  const ReportScreen({super.key, required this.session});
  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen> with TickerProviderStateMixin {
  final _inference = InferenceService();
  final _logger = LoggerService();

  bool _processing = true;
  bool _pdfLoading = false;
  String? _pdfPath;
  String _step = 'Extracting behavioral signals...';

  late AnimationController _fadeCtrl;
  late AnimationController _scoresCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _scoresCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 1200));
    _analyze();
  }

  Future<void> _analyze() async {
    setState(() => _step = 'Extracting 12 behavioral signals...');
    await Future.delayed(const Duration(milliseconds: 500));

    final features = FeatureExtractor.extract(widget.session);
    widget.session.features = features;
    await _logger.saveFeatures(widget.session.id, features);

    setState(() => _step = 'Running AI classifiers...');
    await Future.delayed(const Duration(milliseconds: 400));

    try { await _inference.loadModels(); } catch (_) {}
    final scores = await _inference.runInference(widget.session);
    widget.session.dyslexiaRisk = scores['dyslexia'] ?? 0.0;
    widget.session.adhdRisk = scores['adhd'] ?? 0.0;
    widget.session.autismRisk = scores['autism'] ?? 0.0;

    setState(() => _step = 'Saving results...');
    await _logger.updateSessionRisks(widget.session);

    setState(() => _processing = false);
    _fadeCtrl.forward();
    _scoresCtrl.forward();
  }

  Future<void> _makePdf() async {
    setState(() => _pdfLoading = true);
    try {
      final path = await PdfReportService.generateReport(widget.session);
      setState(() { _pdfPath = path; _pdfLoading = false; });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: const Text('PDF saved to device!'),
          backgroundColor: AppColors.green,
          behavior: SnackBarBehavior.floating,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ));
      }
    } catch (e) {
      setState(() => _pdfLoading = false);
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('PDF error: $e'), backgroundColor: AppColors.red));
    }
  }

  Future<void> _sharePdf() async {
    if (_pdfPath == null) { await _makePdf(); if (_pdfPath == null) return; }
    final file = XFile(_pdfPath!);
    await Share.shareXFiles(
      [file],
      subject: 'ClearPath Report — ${widget.session.childName}',
      text: 'Screening report for ${widget.session.childName}, Age ${widget.session.childAge}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: _processing ? _loadingView() : _reportView(),
      ),
    );
  }

  Widget _loadingView() => Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          width: 80, height: 80,
          decoration: BoxDecoration(color: AppColors.cardPurple, shape: BoxShape.circle),
          child: const Padding(
            padding: EdgeInsets.all(20),
            child: CircularProgressIndicator(strokeWidth: 3, color: AppColors.primary),
          ),
        ),
        const SizedBox(height: 24),
        const Text('Analyzing Results', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.textDark)),
        const SizedBox(height: 8),
        Text(_step, style: const TextStyle(color: AppColors.textMid, fontSize: 14)),
        const SizedBox(height: 20),
        Text('${widget.session.events.length} events recorded',
          style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700, fontSize: 14)),
      ],
    ),
  );

  Widget _reportView() => FadeTransition(
    opacity: _fadeCtrl,
    child: SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _header(),
          const SizedBox(height: 20),
          _riskSection(),
          const SizedBox(height: 20),
          _aiInsights(),
          const SizedBox(height: 20),
          _signalsGrid(),
          const SizedBox(height: 20),
          _actions(),
          const SizedBox(height: 20),
          _disclaimer(),
          const SizedBox(height: 30),
        ],
      ),
    ),
  );

  Widget _header() => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFF7C3AED), Color(0xFF9F67FA)]),
      borderRadius: BorderRadius.circular(20),
    ),
    child: Row(
      children: [
        Container(
          width: 48, height: 48,
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
          child: const Icon(Icons.assessment_rounded, color: Colors.white, size: 26),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text('Screening Report', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Colors.white)),
              Text('${widget.session.childName}  ·  Age ${widget.session.childAge}  ·  ${widget.session.events.length} events',
                style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.8))),
            ],
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(10)),
          child: const Text('تقرير', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
        ),
      ],
    ),
  );

  Widget _riskSection() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Risk Assessment', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textDark)),
      const SizedBox(height: 12),
      _riskCard('Dyslexia', 'عسر القراءة', widget.session.dyslexiaRisk, AppColors.dyslexia, '🔤'),
      const SizedBox(height: 10),
      _riskCard('ADHD', 'اضطراب التركيز', widget.session.adhdRisk, AppColors.adhd, '⭐'),
      const SizedBox(height: 10),
      _riskCard('Autism Spectrum', 'طيف التوحد', widget.session.autismRisk, AppColors.autism, '😊'),
    ],
  );

  Widget _riskCard(String label, String arabic, double score, Color color, String emoji) {
    final pct = (score * 100).round();
    final level = score.riskLevel;
    return AnimatedBuilder(
      animation: _scoresCtrl,
      builder: (_, __) => Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: level == RiskLevel.high ? color.withOpacity(0.4) : Colors.grey.shade100, width: 1.5),
          boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 10, offset: const Offset(0, 4))],
        ),
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  width: 42, height: 42,
                  decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                  child: Center(child: Text(emoji, style: const TextStyle(fontSize: 22))),
                ),
                const SizedBox(width: 12),
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(label, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textDark)),
                  Text(arabic, style: const TextStyle(fontSize: 11, color: AppColors.textMid)),
                ]),
                const Spacer(),
                Text('$pct%', style: TextStyle(color: color, fontSize: 26, fontWeight: FontWeight.w900)),
                const SizedBox(width: 10),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(8)),
                  child: Text(score.riskLabel, style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.w800)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: LinearProgressIndicator(
                value: (score * _scoresCtrl.value).clamp(0, 1),
                minHeight: 10,
                backgroundColor: Colors.grey.shade100,
                valueColor: AlwaysStoppedAnimation(color),
              ),
            ),
            const SizedBox(height: 8),
            Text(score.riskDescription, style: const TextStyle(color: AppColors.textMid, fontSize: 12)),
          ],
        ),
      ),
    );
  }

  // AI-generated insights based on actual signal values
  Widget _aiInsights() {
    final f = widget.session.features;
    if (f.isEmpty) return const SizedBox();

    final insights = <({String icon, String title, String body, Color color})>[];

    // Dyslexia-specific insight
    final errPat = f['error_pattern_score'] ?? 0;
    final errRate = f['error_rate'] ?? 0;
    if (errPat > 0.5) {
      insights.add((icon: '🔤', title: 'Systematic Letter Errors Detected',
        body: '${(errPat * 100).round()}% of errors were the same letter pairs repeated — this is a key dyslexia indicator. The child confused similar-looking Arabic letters consistently, not randomly.',
        color: AppColors.dyslexia));
    } else if (errRate > 0.3) {
      insights.add((icon: '📝', title: 'Elevated Letter Error Rate',
        body: 'Error rate of ${(errRate * 100).round()}% was above average. Errors appeared random rather than systematic — watch for pattern development.',
        color: AppColors.dyslexia));
    }

    // ADHD-specific insight
    final drift = f['attention_drift_index'] ?? 0;
    final impulse = f['impulsivity_score'] ?? 0;
    final variance = f['response_time_variance'] ?? 0;
    if (drift < -0.15) {
      insights.add((icon: '📉', title: 'Significant Attention Drift',
        body: 'Accuracy dropped ${(drift.abs() * 100).round()}% from the start to the end of tasks. The child started well but performance declined — a key ADHD attention marker.',
        color: AppColors.adhd));
    }
    if (impulse > 0.25) {
      insights.add((icon: '⚡', title: 'High Impulsivity Observed',
        body: '${(impulse * 100).round()}% of taps were impulsive (before fully processing). The child acted without thinking — consistent with ADHD impulsivity patterns.',
        color: AppColors.adhd));
    }
    if (variance > 0.4) {
      insights.add((icon: '📊', title: 'Highly Variable Response Times',
        body: 'Response time coefficient of variation was ${variance.toStringAsFixed(2)} — very inconsistent. The child was sometimes fast, sometimes very slow, suggesting attention dysregulation.',
        color: AppColors.adhd));
    }

    // Autism-specific insight
    final emotAcc = f['emotion_accuracy'] ?? 0;
    final socialHes = f['social_hesitation_time'] ?? 0;
    final seqMem = f['sequence_memory_score'] ?? 0;
    if (emotAcc < 0.5) {
      insights.add((icon: '😐', title: 'Low Emotion Recognition',
        body: 'The child correctly identified only ${(emotAcc * 100).round()}% of facial expressions. Below-average emotion recognition is a noted autism spectrum indicator.',
        color: AppColors.autism));
    }
    if (socialHes > 1800) {
      insights.add((icon: '🕐', title: 'Extended Social Hesitation',
        body: 'Average response time on social questions was ${(socialHes / 1000).toStringAsFixed(1)}s — significantly above the typical 1.2s. Prolonged hesitation on social content is an autism spectrum marker.',
        color: AppColors.autism));
    }
    if (seqMem < 0.4) {
      insights.add((icon: '🤝', title: 'Social Gesture Memory Difficulty',
        body: 'Sequence memory score was ${(seqMem * 100).round()}%. Difficulty reproducing social gesture sequences is associated with social learning difficulties.',
        color: AppColors.autism));
    }

    // Speed insight
    final meanRt = f['mean_response_time'] ?? 0;
    final engDecay = f['engagement_decay_rate'] ?? 0;
    if (meanRt < 700) {
      insights.add((icon: '🚀', title: 'Very Fast Responses',
        body: 'Average response time was ${meanRt.round()}ms — extremely fast. May indicate impulsive responding rather than careful consideration.',
        color: AppColors.orange));
    } else if (meanRt > 2000) {
      insights.add((icon: '🐢', title: 'Slow Processing Speed',
        body: 'Average response time was ${(meanRt / 1000).toStringAsFixed(1)}s — slower than typical. May indicate processing difficulties or extra caution.',
        color: AppColors.secondary));
    }
    if (engDecay > 0.3) {
      insights.add((icon: '😴', title: 'Engagement Dropped Significantly',
        body: 'Tap rate dropped ${(engDecay * 100).round()}% from the first half to the second half of the session. Fatigue or boredom may have affected later performance.',
        color: AppColors.textMid));
    }

    if (insights.isEmpty) {
      insights.add((
        icon: '✅', title: 'Typical Performance Profile',
        body: 'No significant behavioral indicators were detected across all three screening areas. The child performed within typical developmental ranges.',
        color: AppColors.green,
      ));
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Text('AI Insights', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textDark)),
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.cardPurple, borderRadius: BorderRadius.circular(8)),
              child: const Text('Based on your session data', style: TextStyle(fontSize: 10, color: AppColors.primary, fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        ...insights.map((ins) => Container(
          margin: const EdgeInsets.only(bottom: 10),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(14),
            border: Border(left: BorderSide(color: ins.color, width: 4)),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 8)],
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(ins.icon, style: const TextStyle(fontSize: 24)),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(ins.title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: ins.color)),
                    const SizedBox(height: 4),
                    Text(ins.body, style: const TextStyle(fontSize: 13, color: AppColors.textMid, height: 1.5)),
                  ],
                ),
              ),
            ],
          ),
        )),
      ],
    );
  }

  Widget _signalsGrid() {
    if (widget.session.features.isEmpty) return const SizedBox();
    final sigs = [
      ('⏱ Response Time', 'mean_response_time', 'ms'),
      ('📊 RT Variance', 'response_time_variance', 'CoV'),
      ('❌ Error Rate', 'error_rate', '%'),
      ('🔁 Error Pattern', 'error_pattern_score', ''),
      ('🔄 Retry Rate', 'retry_rate', ''),
      ('📉 Attention Drift', 'attention_drift_index', ''),
      ('⚡ Impulsivity', 'impulsivity_score', ''),
      ('💨 Recovery', 'recovery_speed', 'x'),
      ('😊 Emotion Acc.', 'emotion_accuracy', '%'),
      ('🕐 Social Hesit.', 'social_hesitation_time', 'ms'),
      ('🤝 Seq. Memory', 'sequence_memory_score', ''),
      ('📉 Eng. Decay', 'engagement_decay_rate', ''),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('12 Behavioral Signals', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.textDark)),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 2.2,
          ),
          itemCount: sigs.length,
          itemBuilder: (_, i) {
            final sig = sigs[i];
            final value = widget.session.features[sig.$2] ?? 0.0;
            final display = sig.$3 == 'ms' ? '${value.round()} ms'
                : sig.$3 == '%' ? '${(value * 100).toStringAsFixed(0)}%'
                : value.toStringAsFixed(3);
            return Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.03), blurRadius: 6)]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(sig.$1, style: const TextStyle(color: AppColors.textMid, fontSize: 10, fontWeight: FontWeight.w600), maxLines: 1, overflow: TextOverflow.ellipsis),
                  Text(display, style: const TextStyle(color: AppColors.textDark, fontSize: 15, fontWeight: FontWeight.w800)),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _actions() => Column(
    children: [
      SizedBox(
        width: double.infinity,
        child: ElevatedButton.icon(
          onPressed: _pdfLoading ? null : _makePdf,
          icon: _pdfLoading
            ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
            : const Icon(Icons.picture_as_pdf_rounded),
          label: Text(_pdfLoading ? 'Generating...' : 'Generate PDF Report'),
        ),
      ),
      if (_pdfPath != null) ...[
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _sharePdf,
            icon: const Icon(Icons.share_rounded),
            label: const Text('Share Report'),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.secondary),
          ),
        ),
      ],
      const SizedBox(height: 10),
      SizedBox(
        width: double.infinity,
        child: OutlinedButton.icon(
          onPressed: () => Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false),
          icon: const Icon(Icons.home_rounded),
          label: const Text('New Screening'),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppColors.primary,
            side: const BorderSide(color: AppColors.primary),
            padding: const EdgeInsets.symmetric(vertical: 14),
          ),
        ),
      ),
    ],
  );

  Widget _disclaimer() => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(
      color: const Color(0xFFFFFBEB),
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: AppColors.yellow.withOpacity(0.5)),
    ),
    child: const Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('⚠️', style: TextStyle(fontSize: 16)),
        SizedBox(width: 8),
        Expanded(
          child: Text(
            'This is a screening tool, not a medical diagnosis. Always consult a qualified specialist for any concerns identified. All data stays on this device — nothing is transmitted.',
            style: TextStyle(fontSize: 11, color: AppColors.textMid, height: 1.5),
          ),
        ),
      ],
    ),
  );

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _scoresCtrl.dispose();
    super.dispose();
  }
}
