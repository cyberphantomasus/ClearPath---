import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';
import '../widgets/game_toast.dart';

/// Game 2 — Star Reaction Game (ADHD Screen)
/// - Random number of stars each round (5–12)
/// - Most stars are RED, exactly ONE is GREEN (or zero for trick rounds)
/// - Randomized positions every round
/// - Strict countdown timer — auto-advance on timeout
/// - Tracks exact response time per round

class Game2Screen extends StatefulWidget {
  final SessionModel session;
  const Game2Screen({super.key, required this.session});
  @override
  State<Game2Screen> createState() => _Game2ScreenState();
}

class _Star {
  final double x;  // 0..1 normalized
  final double y;
  final bool isGreen;
  _Star({required this.x, required this.y, required this.isGreen});
}

class _Game2ScreenState extends State<Game2Screen> with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _rng = Random();

  static const _totalRounds = 18;
  static const _timeLimitMs = 3000; // 3 seconds per round
  static const _trickRoundChance = 0.2; // 20% trick rounds (no green star)

  int _round = 0;
  List<_Star> _stars = [];
  bool _hasGreenStar = false;
  bool _answered = false;
  bool _gameOver = false;
  DateTime? _roundStart;
  int _timeLeftMs = _timeLimitMs;
  Timer? _clockTimer;

  int _correct = 0;
  int _wrong = 0;
  int _timeouts = 0;
  final List<int> _responseTimes = [];

  late AnimationController _starsAppear;
  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _starsAppear = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _pulseCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 900))..repeat(reverse: true);
    _tts.speak(TtsService.game2Intro);
    Future.delayed(const Duration(seconds: 2), _nextRound);
  }

  void _nextRound() {
    if (!mounted) return;
    if (_round >= _totalRounds) { _endGame(); return; }
    _clockTimer?.cancel();

    // Random star count: 5–12
    final starCount = 5 + _rng.nextInt(8);
    final isTrickRound = _rng.nextDouble() < _trickRoundChance;

    // Generate non-overlapping positions
    final positions = _generatePositions(starCount);
    final greenIdx = isTrickRound ? -1 : _rng.nextInt(starCount);

    final stars = List.generate(starCount, (i) => _Star(
      x: positions[i].dx,
      y: positions[i].dy,
      isGreen: i == greenIdx,
    ));

    setState(() {
      _stars = stars;
      _hasGreenStar = !isTrickRound;
      _answered = false;
      _timeLeftMs = _timeLimitMs;
      _roundStart = DateTime.now();
    });

    _starsAppear.forward(from: 0);

    _clockTimer = Timer.periodic(const Duration(milliseconds: 80), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_roundStart!).inMilliseconds;
      final left = _timeLimitMs - elapsed;
      setState(() => _timeLeftMs = left.clamp(0, _timeLimitMs));
      if (left <= 0) { t.cancel(); _onTimeout(); }
    });
  }

  List<Offset> _generatePositions(int count) {
    // Generate positions within play field (avoiding edges and overlaps)
    final positions = <Offset>[];
    int attempts = 0;
    while (positions.length < count && attempts < 200) {
      attempts++;
      final x = 0.08 + _rng.nextDouble() * 0.84;
      final y = 0.05 + _rng.nextDouble() * 0.88;
      final candidate = Offset(x, y);
      bool tooClose = positions.any((p) =>
        (p.dx - x).abs() < 0.18 && (p.dy - y).abs() < 0.18);
      if (!tooClose) positions.add(candidate);
    }
    // Fill remaining if needed
    while (positions.length < count) {
      positions.add(Offset(0.1 + _rng.nextDouble() * 0.8, 0.1 + _rng.nextDouble() * 0.8));
    }
    return positions;
  }

  Future<void> _onStarTap(_Star star) async {
    if (_answered || _gameOver) return;
    _clockTimer?.cancel();
    final rt = DateTime.now().difference(_roundStart!).inMilliseconds;

    final isCorrect = star.isGreen;
    setState(() {
      _answered = true;
      if (isCorrect) _correct++; else _wrong++;
    });
    _responseTimes.add(rt);

    final event = InteractionEvent(
      gameId: 2,
      actionType: isCorrect ? 'correct' : 'false_tap',
      value: rt.toDouble(),
      metadata: star.isGreen ? 'green' : 'red',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) {
      GameToast.show(context,
        type: getToastType(correct: isCorrect, timedOut: false, responseTimeMs: rt),
        responseTimeMs: rt,
      );
    }
    await Future.delayed(const Duration(milliseconds: 500));
    _round++;
    _nextRound();
  }

  Future<void> _onNoGreenTap() async {
    // Player says "no green star" — correct on trick rounds
    if (_answered || _gameOver) return;
    _clockTimer?.cancel();
    final rt = DateTime.now().difference(_roundStart!).inMilliseconds;
    final isCorrect = !_hasGreenStar;

    setState(() {
      _answered = true;
      if (isCorrect) _correct++; else _wrong++;
    });
    _responseTimes.add(rt);

    final event = InteractionEvent(
      gameId: 2,
      actionType: isCorrect ? 'correct' : 'wrong',
      value: rt.toDouble(),
      metadata: 'no_green_tap',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) {
      GameToast.show(context,
        type: getToastType(correct: isCorrect, timedOut: false, responseTimeMs: rt),
        responseTimeMs: rt,
      );
    }
    await Future.delayed(const Duration(milliseconds: 500));
    _round++;
    _nextRound();
  }

  Future<void> _onTimeout() async {
    if (_answered || _gameOver) return;
    setState(() { _answered = true; _timeouts++; });
    _responseTimes.add(_timeLimitMs);

    final event = InteractionEvent(gameId: 2, actionType: 'timeout', value: _timeLimitMs.toDouble());
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) GameToast.show(context, type: ToastType.timeOut, responseTimeMs: 0);
    await Future.delayed(const Duration(milliseconds: 600));
    _round++;
    _nextRound();
  }

  Future<void> _endGame() async {
    _clockTimer?.cancel();
    setState(() => _gameOver = true);
    widget.session.game2Complete = true;
    await _logger.updateSessionRisks(widget.session);
    await Future.delayed(const Duration(milliseconds: 400));
    if (mounted) Navigator.pushReplacementNamed(context, '/game3', arguments: widget.session);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _topBar(),
            _instructionBar(),
            Expanded(child: _playField()),
            _bottomBar(),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Widget _topBar() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    decoration: const BoxDecoration(
      color: AppColors.adhd,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
    ),
    child: Row(
      children: [
        _pill('Game 2 / 3', Colors.white.withOpacity(0.25), Colors.white),
        const Spacer(),
        _timerPill(),
        const SizedBox(width: 10),
        Text('Round ${_round + 1}/$_totalRounds',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
      ],
    ),
  );

  Widget _timerPill() {
    final pct = _timeLeftMs / _timeLimitMs;
    final color = pct > 0.5 ? Colors.white : pct > 0.25 ? AppColors.yellow : Colors.red.shade200;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(100),
      ),
      child: Row(
        children: [
          Icon(Icons.timer_rounded, size: 14, color: color),
          const SizedBox(width: 4),
          Text('${(_timeLeftMs / 1000).toStringAsFixed(1)}s',
            style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13)),
        ],
      ),
    );
  }

  Widget _instructionBar() {
    return Container(
      margin: const EdgeInsets.fromLTRB(16, 12, 16, 0),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: Colors.grey.shade200),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _legendDot(AppColors.green, '= Tap this!'),
          const SizedBox(width: 20),
          _legendDot(AppColors.red, '= Don\'t tap'),
          const SizedBox(width: 20),
          Container(width: 18, height: 18,
            decoration: BoxDecoration(border: Border.all(color: AppColors.textMid, width: 1.5), borderRadius: BorderRadius.circular(4)),
            child: const Icon(Icons.close_rounded, size: 12, color: AppColors.textMid)),
          const SizedBox(width: 4),
          const Text('= No green? Tap here', style: TextStyle(fontSize: 12, color: AppColors.textMid, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _legendDot(Color color, String label) => Row(
    children: [
      Icon(Icons.star_rounded, color: color, size: 20),
      const SizedBox(width: 4),
      Text(label, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w700)),
    ],
  );

  Widget _playField() {
    return LayoutBuilder(builder: (context, constraints) {
      final w = constraints.maxWidth;
      final h = constraints.maxHeight;
      return GestureDetector(
        onTap: () {
          // Tapping empty area counts as "I see no green star"
          if (!_answered) _onNoGreenTap();
        },
        child: Container(
          margin: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              colors: [Color(0xFFFFF8F0), Color(0xFFFFF0DC)],
              begin: Alignment.topLeft, end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: AppColors.adhd.withOpacity(0.2), width: 2),
          ),
          child: Stack(
            children: [
              // Timer bar overlay
              Positioned(
                left: 0, right: 0, top: 0,
                child: ClipRRect(
                  borderRadius: const BorderRadius.vertical(top: Radius.circular(22)),
                  child: LinearProgressIndicator(
                    value: _timeLeftMs / _timeLimitMs,
                    minHeight: 5,
                    backgroundColor: Colors.grey.shade200,
                    valueColor: AlwaysStoppedAnimation(
                      _timeLeftMs / _timeLimitMs > 0.5 ? AppColors.green :
                      _timeLeftMs / _timeLimitMs > 0.25 ? AppColors.orange : AppColors.red,
                    ),
                  ),
                ),
              ),
              // Stars
              ..._stars.asMap().entries.map((e) {
                final i = e.key;
                final star = e.value;
                return Positioned(
                  left: star.x * (w - 56),
                  top: star.y * (h - 56),
                  child: AnimatedBuilder(
                    animation: _starsAppear,
                    builder: (_, __) {
                      final delay = (i * 0.05).clamp(0.0, 0.5);
                      final t = ((_starsAppear.value - delay) / (1.0 - delay)).clamp(0.0, 1.0);
                      return Transform.scale(
                        scale: Curves.elasticOut.transform(t),
                        child: _StarWidget(
                          star: star,
                          answered: _answered,
                          pulseAnim: _pulseCtrl,
                          onTap: () => _onStarTap(star),
                        ),
                      );
                    },
                  ),
                );
              }),
              // Trick round hint
              if (_stars.isNotEmpty && !_answered)
                Positioned(
                  bottom: 16, left: 0, right: 0,
                  child: Center(
                    child: Text(
                      'Tap a GREEN ⭐ or tap anywhere if there\'s none',
                      style: TextStyle(fontSize: 11, color: AppColors.textMid.withOpacity(0.6), fontWeight: FontWeight.w500),
                      textAlign: TextAlign.center,
                    ),
                  ),
                ),
            ],
          ),
        ),
      );
    });
  }

  Widget _bottomBar() {
    final avg = _responseTimes.isEmpty ? 0 : _responseTimes.reduce((a, b) => a + b) ~/ _responseTimes.length;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _chip('✅ $_correct', AppColors.green),
          _chip('❌ $_wrong', AppColors.red),
          _chip('⏰ $_timeouts', AppColors.orange),
          _chip('⚡ ${avg}ms', AppColors.primary),
        ],
      ),
    );
  }

  Widget _chip(String label, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(10), border: Border.all(color: c.withOpacity(0.25))),
    child: Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w800, fontSize: 11)),
  );

  Widget _pill(String t, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(100)),
    child: Text(t, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
  );

  @override
  void dispose() {
    _clockTimer?.cancel();
    _starsAppear.dispose();
    _pulseCtrl.dispose();
    super.dispose();
  }
}

class _StarWidget extends StatelessWidget {
  final _Star star;
  final bool answered;
  final Animation<double> pulseAnim;
  final VoidCallback onTap;

  const _StarWidget({required this.star, required this.answered, required this.pulseAnim, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final color = star.isGreen ? AppColors.green : AppColors.red;
    return GestureDetector(
      onTap: answered ? null : onTap,
      child: AnimatedBuilder(
        animation: pulseAnim,
        builder: (_, __) {
          final pulse = star.isGreen ? (1.0 + pulseAnim.value * 0.15) : 1.0;
          return Transform.scale(
            scale: pulse,
            child: Container(
              width: 52, height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: color.withOpacity(0.12),
                boxShadow: star.isGreen ? [BoxShadow(color: AppColors.green.withOpacity(0.4), blurRadius: 12, spreadRadius: 2)] : null,
              ),
              child: Icon(Icons.star_rounded, color: color, size: 44),
            ),
          );
        },
      ),
    );
  }
}
