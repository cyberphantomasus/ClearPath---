import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';
import '../widgets/game_toast.dart';

class Game3Screen extends StatefulWidget {
  final SessionModel session;
  const Game3Screen({super.key, required this.session});
  @override
  State<Game3Screen> createState() => _Game3ScreenState();
}

class _Game3ScreenState extends State<Game3Screen> with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _rng = Random();

  static const _emotions = [
    (emoji: '😊', label: 'Happy', options: ['Happy', 'Sad', 'Angry', 'Surprised']),
    (emoji: '😢', label: 'Sad', options: ['Happy', 'Sad', 'Scared', 'Tired']),
    (emoji: '😠', label: 'Angry', options: ['Happy', 'Angry', 'Surprised', 'Sad']),
    (emoji: '😨', label: 'Scared', options: ['Happy', 'Scared', 'Angry', 'Surprised']),
    (emoji: '😴', label: 'Tired', options: ['Happy', 'Tired', 'Sad', 'Bored']),
    (emoji: '🤩', label: 'Excited', options: ['Excited', 'Happy', 'Scared', 'Surprised']),
    (emoji: '🥺', label: 'Worried', options: ['Happy', 'Worried', 'Sad', 'Angry']),
    (emoji: '😐', label: 'Neutral', options: ['Happy', 'Neutral', 'Sad', 'Tired']),
  ];

  static const _gestures = [
    ['👋', '✊', '✌️'],
    ['✊', '✌️', '👋'],
    ['✌️', '👋', '✊'],
    ['👋', '✌️', '✊', '👋'],
  ];

  static const _totalRounds = 15;
  static const _timeLimitMs = 6000;

  int _round = 0;
  String _taskType = 'emotion';
  DateTime? _roundStart;
  bool _answered = false;
  bool _gameOver = false;
  int _correct = 0;
  int _wrong = 0;
  int _timeLeftMs = _timeLimitMs;
  Timer? _clockTimer;

  dynamic _emotion;
  List<String> _options = [];
  String? _selectedOption;

  List<String> _sequence = [];
  List<String> _playerSeq = [];
  bool _showingSeq = true;
  int _seqIdx = 0;
  Timer? _seqTimer;

  late AnimationController _fadeCtrl;
  late AnimationController _bounceCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 500));
    _tts.speak(TtsService.game3Intro);
    Future.delayed(const Duration(seconds: 2), _nextRound);
  }

  void _nextRound() {
    if (!mounted) return;
    if (_round >= _totalRounds) { _endGame(); return; }
    _clockTimer?.cancel();
    _seqTimer?.cancel();
    _fadeCtrl.forward(from: 0);

    final taskIndex = _round % 3;
    setState(() {
      _answered = false;
      _selectedOption = null;
      _timeLeftMs = _timeLimitMs;
      _roundStart = DateTime.now();

      if (taskIndex < 2) {
        _taskType = 'emotion';
        _emotion = _emotions[_rng.nextInt(_emotions.length)];
        _options = List.from(_emotion.options)..shuffle(_rng);
      } else {
        _taskType = 'sequence';
        _sequence = List.from(_gestures[_rng.nextInt(_gestures.length)]);
        _playerSeq = [];
        _showingSeq = true;
        _seqIdx = 0;
        _playSequence();
      }
    });

    if (_taskType == 'emotion') {
      _bounceCtrl.forward(from: 0);
      _startClock();
    }
  }

  void _startClock() {
    _clockTimer = Timer.periodic(const Duration(milliseconds: 100), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_roundStart!).inMilliseconds;
      final left = _timeLimitMs - elapsed;
      setState(() => _timeLeftMs = left.clamp(0, _timeLimitMs));
      if (left <= 0) { t.cancel(); _onTimeout(); }
    });
  }

  void _playSequence() {
    int i = 0;
    _seqTimer = Timer.periodic(const Duration(milliseconds: 700), (t) {
      if (!mounted) { t.cancel(); return; }
      if (i < _sequence.length) {
        setState(() => _seqIdx = i);
        i++;
      } else {
        t.cancel();
        setState(() => _showingSeq = false);
        _roundStart = DateTime.now();
        _startClock();
      }
    });
  }

  Future<void> _onEmotionTap(String selected) async {
    if (_answered) return;
    _clockTimer?.cancel();
    final rt = DateTime.now().difference(_roundStart!).inMilliseconds;
    final isCorrect = selected == _emotion.label;

    setState(() {
      _answered = true;
      _selectedOption = selected;
      if (isCorrect) _correct++; else _wrong++;
    });

    final event = InteractionEvent(
      gameId: 3,
      actionType: 'emotion_select',
      value: isCorrect ? 1.0 : 0.0,
      metadata: '${_emotion.label}_$selected',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (_round % 3 == 1) {
      final social = InteractionEvent(gameId: 3, actionType: 'social_response', value: rt.toDouble());
      widget.session.addEvent(social);
      await _logger.logEvent(widget.session.id, social);
    }

    if (mounted) {
      GameToast.show(context,
        type: getToastType(correct: isCorrect, timedOut: false, responseTimeMs: rt),
        responseTimeMs: rt,
      );
    }
    await Future.delayed(const Duration(milliseconds: 500));
    _round++;
    _nextRound();
  }

  Future<void> _onGestureTap(String g) async {
    if (_showingSeq || _answered) return;
    _playerSeq.add(g);
    final idx = _playerSeq.length - 1;
    final isCorrect = idx < _sequence.length && _playerSeq[idx] == _sequence[idx];

    final event = InteractionEvent(gameId: 3, actionType: 'sequence_tap', value: isCorrect ? 1.0 : 0.0, metadata: g);
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (!isCorrect || _playerSeq.length == _sequence.length) {
      final allCorrect = _playerSeq.length == _sequence.length &&
          List.generate(_sequence.length, (i) => _playerSeq[i] == _sequence[i]).every((v) => v);

      _clockTimer?.cancel();
      final rt = DateTime.now().difference(_roundStart!).inMilliseconds;
      setState(() { _answered = true; if (allCorrect) _correct++; else _wrong++; });

      if (mounted) {
        GameToast.show(context,
          type: getToastType(correct: allCorrect, timedOut: false, responseTimeMs: rt),
          responseTimeMs: rt,
        );
      }
      await Future.delayed(const Duration(milliseconds: 600));
      _round++;
      _nextRound();
    } else {
      setState(() {});
    }
  }

  Future<void> _onTimeout() async {
    if (_answered || _gameOver) return;
    _clockTimer?.cancel();
    setState(() { _answered = true; _wrong++; });

    final event = InteractionEvent(gameId: 3, actionType: 'timeout', value: _timeLimitMs.toDouble());
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) GameToast.show(context, type: ToastType.timeOut, responseTimeMs: 0);
    await Future.delayed(const Duration(milliseconds: 600));
    _round++;
    _nextRound();
  }

  Future<void> _endGame() async {
    _clockTimer?.cancel();
    _seqTimer?.cancel();
    setState(() => _gameOver = true);
    widget.session.game3Complete = true;
    await _logger.updateSessionRisks(widget.session);
    if (mounted) Navigator.pushReplacementNamed(context, '/report', arguments: widget.session);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _topBar(),
            Expanded(
              child: _gameOver
                ? _completing()
                : FadeTransition(
                    opacity: _fadeCtrl,
                    child: _taskType == 'emotion' ? _emotionTask() : _sequenceTask(),
                  ),
            ),
            _statsBar(),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _topBar() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    decoration: const BoxDecoration(
      color: AppColors.autism,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
    ),
    child: Row(
      children: [
        _pill('Game 3 / 3', Colors.white.withOpacity(0.25), Colors.white),
        const Spacer(),
        _timerChip(),
        const SizedBox(width: 10),
        Text('Round ${_round + 1}/$_totalRounds', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 13)),
      ],
    ),
  );

  Widget _timerChip() {
    final pct = _timeLeftMs / _timeLimitMs;
    final color = pct > 0.5 ? Colors.white : pct > 0.25 ? AppColors.yellow : Colors.red.shade200;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(100)),
      child: Text('${(_timeLeftMs / 1000).toStringAsFixed(1)}s', style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13)),
    );
  }

  Widget _emotionTask() => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
      children: [
        const Text('How does this face feel?',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700, color: AppColors.textDark)),
        const SizedBox(height: 20),
        ScaleTransition(
          scale: Tween(begin: 0.6, end: 1.0).animate(CurvedAnimation(parent: _bounceCtrl, curve: Curves.elasticOut)),
          child: Container(
            width: 130, height: 130,
            decoration: BoxDecoration(
              color: const Color(0xFFF0FDF4),
              shape: BoxShape.circle,
              border: Border.all(color: AppColors.autism.withOpacity(0.3), width: 3),
              boxShadow: [BoxShadow(color: AppColors.autism.withOpacity(0.2), blurRadius: 20)],
            ),
            child: Center(child: Text(_emotion?.emoji ?? '', style: const TextStyle(fontSize: 72))),
          ),
        ),
        const SizedBox(height: 8),
        // Timer bar
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: _timeLeftMs / _timeLimitMs,
              minHeight: 6,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation(
                _timeLeftMs / _timeLimitMs > 0.5 ? AppColors.autism : AppColors.orange,
              ),
            ),
          ),
        ),
        const SizedBox(height: 20),
        GridView.count(
          crossAxisCount: 2, shrinkWrap: true,
          crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: 2.5,
          children: _options.map((opt) {
            final isSelected = opt == _selectedOption;
            final isCorrect = opt == _emotion?.label;
            Color bg = Colors.white;
            Color border = Colors.grey.shade200;
            if (_answered) {
              if (isCorrect) { bg = const Color(0xFFF0FDF4); border = AppColors.green; }
              else if (isSelected) { bg = const Color(0xFFFEF2F2); border = AppColors.red; }
            }
            return GestureDetector(
              onTap: _answered ? null : () => _onEmotionTap(opt),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                decoration: BoxDecoration(
                  color: bg, borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: border, width: 2),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
                ),
                child: Center(child: Text(opt, style: const TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textDark))),
              ),
            );
          }).toList(),
        ),
      ],
    ),
  );

  Widget _sequenceTask() => Padding(
    padding: const EdgeInsets.all(20),
    child: Column(
      children: [
        Text(_showingSeq ? 'Watch carefully!' : 'Now repeat it!',
          style: TextStyle(
            fontSize: 20, fontWeight: FontWeight.w800,
            color: _showingSeq ? AppColors.autism : AppColors.orange,
          )),
        const SizedBox(height: 20),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_sequence.length, (i) {
            final isActive = _showingSeq && i == _seqIdx;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 8),
              width: 64, height: 64,
              decoration: BoxDecoration(
                color: isActive ? AppColors.autism.withOpacity(0.15) : Colors.white,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: isActive ? AppColors.autism : Colors.grey.shade200, width: 2.5),
                boxShadow: isActive ? [BoxShadow(color: AppColors.autism.withOpacity(0.3), blurRadius: 12)] : null,
              ),
              child: Center(
                child: Text(
                  _showingSeq ? (i <= _seqIdx ? _sequence[i] : '?') : _sequence[i],
                  style: const TextStyle(fontSize: 32),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 20),
        if (!_showingSeq) ...[
          const Text('Your answer:', style: TextStyle(color: AppColors.textMid, fontSize: 14, fontWeight: FontWeight.w600)),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(_sequence.length, (i) => Container(
              margin: const EdgeInsets.symmetric(horizontal: 6),
              width: 54, height: 54,
              decoration: BoxDecoration(
                color: i < _playerSeq.length ? AppColors.autism.withOpacity(0.1) : Colors.grey.shade100,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: i < _playerSeq.length ? AppColors.autism : Colors.grey.shade300, width: 2),
              ),
              child: Center(child: Text(i < _playerSeq.length ? _playerSeq[i] : '', style: const TextStyle(fontSize: 28))),
            )),
          ),
          const SizedBox(height: 24),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: ['👋', '✊', '✌️'].map((g) => GestureDetector(
              onTap: () => _onGestureTap(g),
              child: Container(
                margin: const EdgeInsets.symmetric(horizontal: 10),
                width: 76, height: 76,
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(18),
                  border: Border.all(color: Colors.grey.shade200, width: 2),
                  boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 4))],
                ),
                child: Center(child: Text(g, style: const TextStyle(fontSize: 40))),
              ),
            )).toList(),
          ),
        ],
      ],
    ),
  );

  Widget _completing() => const Center(
    child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('🎉', style: TextStyle(fontSize: 70)),
        SizedBox(height: 16),
        Text('All done!', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: AppColors.textDark)),
        SizedBox(height: 8),
        Text('Generating your report...', style: TextStyle(color: AppColors.textMid, fontSize: 16)),
      ],
    ),
  );

  Widget _statsBar() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        _chip('✅ $_correct', AppColors.green),
        const SizedBox(width: 12),
        _chip('❌ $_wrong', AppColors.red),
      ],
    ),
  );

  Widget _chip(String label, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
    decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: c.withOpacity(0.25))),
    child: Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w800, fontSize: 13)),
  );

  Widget _pill(String t, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(100)),
    child: Text(t, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
  );

  @override
  void dispose() {
    _clockTimer?.cancel();
    _seqTimer?.cancel();
    _fadeCtrl.dispose();
    _bounceCtrl.dispose();
    super.dispose();
  }
}
