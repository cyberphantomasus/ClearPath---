import 'package:flutter/material.dart';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final _nameCtrl = TextEditingController();
  final _logger = LoggerService();
  final _tts = TtsService();
  int _age = 6;
  List<Map<String, dynamic>> _past = [];
  late AnimationController _headerAnim;

  @override
  void initState() {
    super.initState();
    _tts.init();
    _headerAnim = AnimationController(vsync: this, duration: const Duration(milliseconds: 800))..forward();
    _loadPast();
  }

  Future<void> _loadPast() async {
    final s = await _logger.getAllSessions();
    setState(() => _past = s.take(4).toList());
  }

  void _start() async {
    final name = _nameCtrl.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: const Text('Please enter the child\'s name'), backgroundColor: AppColors.red, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)), behavior: SnackBarBehavior.floating),
      );
      return;
    }
    final session = SessionModel(childName: name, childAge: _age);
    await _logger.saveSession(session);
    if (mounted) Navigator.pushNamed(context, '/game1', arguments: session);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _hero(),
              const SizedBox(height: 24),
              _inputCard(),
              const SizedBox(height: 20),
              _gamesPreview(),
              if (_past.isNotEmpty) ...[const SizedBox(height: 20), _history()],
              const SizedBox(height: 32),
            ],
          ),
        ),
      ),
    );
  }

  Widget _hero() => SlideTransition(
    position: Tween<Offset>(begin: const Offset(0, -0.3), end: Offset.zero)
        .animate(CurvedAnimation(parent: _headerAnim, curve: Curves.easeOut)),
    child: Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF7C3AED), Color(0xFF9F67FA)],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: AppColors.primary.withOpacity(0.35), blurRadius: 20, offset: const Offset(0, 8))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 52, height: 52,
                decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(14)),
                child: const Icon(Icons.psychology_rounded, color: Colors.white, size: 30),
              ),
              const SizedBox(width: 14),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('ClearPath', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w800, color: Colors.white)),
                  Text('كلير باث', style: TextStyle(fontSize: 12, color: Colors.white.withOpacity(0.7))),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Text('Child Developmental\nScreening', style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Colors.white, height: 1.2)),
          const SizedBox(height: 8),
          Row(
            children: [
              _badge('🆓 Free'),
              const SizedBox(width: 8),
              _badge('📡 Offline'),
              const SizedBox(width: 8),
              _badge('⏱ 10 min'),
            ],
          ),
        ],
      ),
    ),
  );

  Widget _badge(String label) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
    decoration: BoxDecoration(color: Colors.white.withOpacity(0.2), borderRadius: BorderRadius.circular(100)),
    child: Text(label, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.w600)),
  );

  Widget _inputCard() => Card(
    child: Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Start New Screening', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w700, color: AppColors.textDark)),
          const SizedBox(height: 16),
          TextField(
            controller: _nameCtrl,
            style: const TextStyle(fontSize: 15, color: AppColors.textDark, fontWeight: FontWeight.w600),
            decoration: InputDecoration(
              labelText: 'Child\'s Name',
              hintText: 'Enter name here',
              prefixIcon: const Icon(Icons.person_outline_rounded, color: AppColors.primary),
              filled: true,
              fillColor: AppColors.cardPurple,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.primary, width: 2)),
            ),
          ),
          const SizedBox(height: 16),
          const Text('Age', style: TextStyle(fontSize: 14, fontWeight: FontWeight.w700, color: AppColors.textDark)),
          const SizedBox(height: 10),
          SizedBox(
            height: 46,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: 9,
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final age = i + 4;
                final sel = age == _age;
                return GestureDetector(
                  onTap: () => setState(() => _age = age),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 46, height: 46,
                    decoration: BoxDecoration(
                      color: sel ? AppColors.primary : AppColors.cardPurple,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(color: sel ? AppColors.primary : Colors.transparent, width: 2),
                      boxShadow: sel ? [BoxShadow(color: AppColors.primary.withOpacity(0.3), blurRadius: 8)] : null,
                    ),
                    child: Center(child: Text('$age',
                      style: TextStyle(color: sel ? Colors.white : AppColors.textMid, fontWeight: FontWeight.w700, fontSize: 15))),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _start,
              icon: const Icon(Icons.play_circle_filled_rounded, size: 22),
              label: const Text('Begin Screening'),
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            ),
          ),
        ],
      ),
    ),
  );

  Widget _gamesPreview() {
    const games = [
      (icon: '🔤', label: 'Letter Match', sub: 'Dyslexia', color: AppColors.dyslexia, bg: AppColors.cardPurple),
      (icon: '⭐', label: 'Star Finder', sub: 'ADHD', color: AppColors.adhd, bg: AppColors.cardYellow),
      (icon: '😊', label: 'Emotions', sub: 'Autism', color: AppColors.autism, bg: AppColors.cardGreen),
    ];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('3 Mini-Games · 10 Minutes', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textDark)),
        const SizedBox(height: 12),
        Row(
          children: games.map((g) => Expanded(
            child: Container(
              margin: const EdgeInsets.only(right: games.indexOf(g) < 2 ? 10 : 0),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: g.bg, borderRadius: BorderRadius.circular(16),
                border: Border.all(color: g.color.withOpacity(0.15)),
              ),
              child: Column(
                children: [
                  Text(g.icon, style: const TextStyle(fontSize: 28)),
                  const SizedBox(height: 6),
                  Text(g.label, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: AppColors.textDark), textAlign: TextAlign.center),
                  const SizedBox(height: 3),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                    decoration: BoxDecoration(color: g.color.withOpacity(0.12), borderRadius: BorderRadius.circular(100)),
                    child: Text(g.sub, style: TextStyle(fontSize: 10, color: g.color, fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
            ),
          )).toList(),
        ),
      ],
    );
  }

  Widget _history() => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      const Text('Recent Sessions', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w700, color: AppColors.textDark)),
      const SizedBox(height: 10),
      ..._past.map((s) {
        final date = DateTime.fromMillisecondsSinceEpoch(s['start_time'] as int);
        final d = ((s['dyslexia_risk'] as double? ?? 0) * 100).round();
        final a = ((s['adhd_risk'] as double? ?? 0) * 100).round();
        final au = ((s['autism_risk'] as double? ?? 0) * 100).round();
        return Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14),
            border: Border.all(color: Colors.grey.shade100),
            boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)]),
          child: Row(
            children: [
              Container(width: 38, height: 38,
                decoration: BoxDecoration(color: AppColors.cardPurple, borderRadius: BorderRadius.circular(10)),
                child: const Icon(Icons.history_rounded, color: AppColors.primary, size: 20)),
              const SizedBox(width: 12),
              Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(s['child_name'] as String, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
                  Text('Age ${s['child_age']}  ·  ${date.day}/${date.month}/${date.year}',
                    style: const TextStyle(fontSize: 11, color: AppColors.textMid)),
                ],
              )),
              Row(children: [
                _miniScore('D:$d%', AppColors.dyslexia),
                const SizedBox(width: 4),
                _miniScore('A:$a%', AppColors.adhd),
                const SizedBox(width: 4),
                _miniScore('Au:$au%', AppColors.autism),
              ]),
            ],
          ),
        );
      }),
    ],
  );

  Widget _miniScore(String text, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
    decoration: BoxDecoration(color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
    child: Text(text, style: TextStyle(color: c, fontSize: 10, fontWeight: FontWeight.w800)),
  );

  @override
  void dispose() {
    _nameCtrl.dispose();
    _headerAnim.dispose();
    super.dispose();
  }
}
