import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';
import '../widgets/game_toast.dart';

class Game1Screen extends StatefulWidget {
  final SessionModel session;
  const Game1Screen({super.key, required this.session});
  @override
  State<Game1Screen> createState() => _Game1ScreenState();
}

class _Game1ScreenState extends State<Game1Screen> with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _rng = Random();

  // 4 HIGHLY SIMILAR Arabic letters per group — visually almost identical
  static const _groups = [
    ['ب', 'ت', 'ث', 'ن'],
    ['ج', 'ح', 'خ', 'ع'],
    ['د', 'ذ', 'ر', 'ز'],
    ['س', 'ش', 'ص', 'ض'],
    ['ط', 'ظ', 'ع', 'غ'],
    ['ف', 'ق', 'ن', 'ي'],
    ['ك', 'ل', 'م', 'ن'],
    ['ه', 'ة', 'و', 'ا'],
    ['ي', 'ب', 'ن', 'ت'],
    ['ص', 'ض', 'ط', 'ظ'],
  ];

  static const _totalRounds = 20;
  static const _timeLimitMs = 5000;

  int _round = 0;
  String _target = '';
  List<String> _choices = [];
  DateTime? _roundStart;
  bool _answered = false;
  int? _selectedIdx;
  bool _gameOver = false;
  int _correct = 0;
  int _wrong = 0;
  final List<int> _responseTimes = [];
  int _timeLeftMs = _timeLimitMs;
  Timer? _clockTimer;

  late AnimationController _bounceCtrl;
  late AnimationController _fadeCtrl;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 250));
    _tts.speak(TtsService.game1Intro);
    Future.delayed(const Duration(seconds: 2), _nextRound);
  }

  void _nextRound() {
    if (!mounted) return;
    if (_round >= _totalRounds) { _endGame(); return; }
    _clockTimer?.cancel();

    final group = List<String>.from(_groups[_rng.nextInt(_groups.length)])..shuffle(_rng);
    setState(() {
      _target = group[0];
      _choices = group;
      _answered = false;
      _selectedIdx = null;
      _timeLeftMs = _timeLimitMs;
      _roundStart = DateTime.now();
    });

    _bounceCtrl.forward(from: 0);
    _fadeCtrl.forward(from: 0);

    _clockTimer = Timer.periodic(const Duration(milliseconds: 100), (t) {
      if (!mounted) { t.cancel(); return; }
      final elapsed = DateTime.now().difference(_roundStart!).inMilliseconds;
      final left = _timeLimitMs - elapsed;
      setState(() => _timeLeftMs = left.clamp(0, _timeLimitMs));
      if (left <= 0) { t.cancel(); _onTimeout(); }
    });
  }

  Future<void> _onTap(int idx) async {
    if (_answered || _gameOver) return;
    _clockTimer?.cancel();
    final rt = DateTime.now().difference(_roundStart!).inMilliseconds;
    final isCorrect = _choices[idx] == _target;

    setState(() {
      _answered = true;
      _selectedIdx = idx;
      if (isCorrect) _correct++; else _wrong++;
    });
    _responseTimes.add(rt);

    final event = InteractionEvent(
      gameId: 1,
      actionType: isCorrect ? 'correct' : 'wrong',
      value: rt.toDouble(),
      metadata: isCorrect ? _target : '${_target}_${_choices[idx]}',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) {
      GameToast.show(context,
        type: getToastType(correct: isCorrect, timedOut: false, responseTimeMs: rt),
        responseTimeMs: rt,
      );
    }
    // Immediate round change after 400ms visual feedback
    await Future.delayed(const Duration(milliseconds: 400));
    _round++;
    _nextRound();
  }

  Future<void> _onTimeout() async {
    if (_answered || _gameOver) return;
    setState(() { _answered = true; _wrong++; });
    _responseTimes.add(_timeLimitMs);

    final event = InteractionEvent(gameId: 1, actionType: 'timeout', value: _timeLimitMs.toDouble(), metadata: _target);
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (mounted) GameToast.show(context, type: ToastType.timeOut, responseTimeMs: 0);
    await Future.delayed(const Duration(milliseconds: 600));
    _round++;
    _nextRound();
  }

  Future<void> _endGame() async {
    _clockTimer?.cancel();
    setState(() => _gameOver = true);
    widget.session.game1Complete = true;
    await _logger.updateSessionRisks(widget.session);
    await Future.delayed(const Duration(milliseconds: 400));
    if (mounted) Navigator.pushReplacementNamed(context, '/game2', arguments: widget.session);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            _topBar(),
            const SizedBox(height: 16),
            _targetCard(),
            const SizedBox(height: 12),
            _timerBar(),
            const SizedBox(height: 14),
            const Text('Tap the matching letter',
              style: TextStyle(fontSize: 15, color: AppColors.textMid, fontWeight: FontWeight.w600)),
            const SizedBox(height: 14),
            Expanded(child: _grid()),
            _stats(),
            const SizedBox(height: 12),
          ],
        ),
      ),
    );
  }

  Widget _topBar() => Container(
    padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 14),
    decoration: const BoxDecoration(
      color: AppColors.dyslexia,
      borderRadius: BorderRadius.vertical(bottom: Radius.circular(24)),
    ),
    child: Row(
      children: [
        _pill('Game 1 / 3', Colors.white.withOpacity(0.25), Colors.white),
        const Spacer(),
        Text('Round ${_round + 1}/$_totalRounds',
          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
      ],
    ),
  );

  Widget _pill(String label, Color bg, Color fg) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
    decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(100)),
    child: Text(label, style: TextStyle(color: fg, fontWeight: FontWeight.w700, fontSize: 12)),
  );

  Widget _targetCard() => Container(
    margin: const EdgeInsets.symmetric(horizontal: 20),
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      gradient: const LinearGradient(colors: [Color(0xFFF5F3FF), Color(0xFFEDE9FE)]),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: AppColors.dyslexia.withOpacity(0.25), width: 2),
    ),
    child: Column(
      children: [
        const Text('Find this letter:', style: TextStyle(fontSize: 14, color: AppColors.textMid, fontWeight: FontWeight.w600)),
        const SizedBox(height: 12),
        ScaleTransition(
          scale: Tween(begin: 0.5, end: 1.0).animate(CurvedAnimation(parent: _bounceCtrl, curve: Curves.elasticOut)),
          child: Container(
            width: 90, height: 90,
            decoration: BoxDecoration(
              color: AppColors.dyslexia,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [BoxShadow(color: AppColors.dyslexia.withOpacity(0.4), blurRadius: 14, offset: const Offset(0, 6))],
            ),
            child: Center(child: Text(_target, style: const TextStyle(fontSize: 52, color: Colors.white, height: 1))),
          ),
        ),
      ],
    ),
  );

  Widget _timerBar() {
    final pct = _timeLeftMs / _timeLimitMs;
    final color = pct > 0.5 ? AppColors.green : pct > 0.25 ? AppColors.orange : AppColors.red;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Icon(Icons.timer_rounded, size: 15, color: color),
              Text('${(_timeLeftMs / 1000).toStringAsFixed(1)}s',
                style: TextStyle(color: color, fontWeight: FontWeight.w800, fontSize: 13)),
            ],
          ),
          const SizedBox(height: 4),
          ClipRRect(
            borderRadius: BorderRadius.circular(6),
            child: LinearProgressIndicator(
              value: pct,
              minHeight: 8,
              backgroundColor: Colors.grey.shade200,
              valueColor: AlwaysStoppedAnimation(color),
            ),
          ),
        ],
      ),
    );
  }

  Widget _grid() => Padding(
    padding: const EdgeInsets.symmetric(horizontal: 20),
    child: FadeTransition(
      opacity: _fadeCtrl,
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, crossAxisSpacing: 14, mainAxisSpacing: 14, childAspectRatio: 1.4,
        ),
        itemCount: 4,
        itemBuilder: (_, idx) {
          if (idx >= _choices.length) return const SizedBox();
          final letter = _choices[idx];
          final isSelected = idx == _selectedIdx;
          final isTarget = letter == _target;

          Color bg = Colors.white;
          Color borderColor = Colors.grey.shade200;

          if (_answered) {
            if (isTarget) { bg = const Color(0xFFF0FDF4); borderColor = AppColors.green; }
            if (isSelected && !isTarget) { bg = const Color(0xFFFEF2F2); borderColor = AppColors.red; }
          }

          return GestureDetector(
            onTap: () => _onTap(idx),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              decoration: BoxDecoration(
                color: bg,
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: borderColor, width: 2.5),
                boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 8, offset: const Offset(0, 3))],
              ),
              child: Stack(
                children: [
                  Center(child: Text(letter, style: const TextStyle(fontSize: 50, color: AppColors.textDark, height: 1))),
                  if (_answered && (isTarget || (isSelected && !isTarget)))
                    Positioned(top: 8, right: 8,
                      child: Icon(isTarget ? Icons.check_circle_rounded : Icons.cancel_rounded,
                        color: isTarget ? AppColors.green : AppColors.red, size: 22)),
                ],
              ),
            ),
          );
        },
      ),
    ),
  );

  Widget _stats() {
    final avg = _responseTimes.isEmpty ? 0 : _responseTimes.reduce((a, b) => a + b) ~/ _responseTimes.length;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _chip('✅ $_correct', AppColors.green),
          _chip('❌ $_wrong', AppColors.red),
          _chip('⚡ ${avg}ms avg', AppColors.primary),
        ],
      ),
    );
  }

  Widget _chip(String label, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
    decoration: BoxDecoration(
      color: c.withOpacity(0.1), borderRadius: BorderRadius.circular(12),
      border: Border.all(color: c.withOpacity(0.3)),
    ),
    child: Text(label, style: TextStyle(color: c, fontWeight: FontWeight.w800, fontSize: 12)),
  );

  @override
  void dispose() {
    _clockTimer?.cancel();
    _bounceCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }
}
