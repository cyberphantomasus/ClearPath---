import 'package:flutter_tts/flutter_tts.dart';

/// Wraps flutter_tts for Arabic game instructions.
/// Falls back gracefully if TTS is unavailable on the device.
class TtsService {
  static final TtsService _instance = TtsService._internal();
  factory TtsService() => _instance;
  TtsService._internal();

  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> init() async {
    if (_initialized) return;
    try {
      await _tts.setLanguage('ar-SA'); // Arabic — Saudi Arabia
      await _tts.setSpeechRate(0.5);   // Slower for children
      await _tts.setVolume(1.0);
      await _tts.setPitch(1.1);        // Slightly higher pitch — friendlier
      _initialized = true;
    } catch (_) {
      // TTS unavailable — silent fallback
      _initialized = false;
    }
  }

  Future<void> speak(String text) async {
    if (!_initialized) return;
    await _tts.stop();
    await _tts.speak(text);
  }

  Future<void> stop() async {
    await _tts.stop();
  }

  // ─── Pre-written Game Instructions ───────────────────────────────

  // Game 1 — Letter Matching
  static const String game1Intro =
      'Welcome! Look at the letter on top. Tap the matching letter below. Take your time!';

  // Game 2 — Attention Task
  static const String game2Intro =
      'Watch the screen carefully! Tap the star when it appears. Ignore everything else.';

  // Game 3 — Social Recognition
  static const String game3Intro =
      'Look at the face. How is this person feeling? Tap the right answer!';

  static const String wellDone = 'Well done! Keep going!';
  static const String tryAgain = 'Almost! Try again.';
  static const String sessionComplete = 'Great job! You finished all the games!';

  void dispose() {
    _tts.stop();
  }
}
