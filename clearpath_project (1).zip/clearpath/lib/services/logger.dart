import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/session_model.dart';

/// Manages all SQLite persistence for ClearPath.
/// Logs every interaction event to 10ms precision.
class LoggerService {
  static final LoggerService _instance = LoggerService._internal();
  factory LoggerService() => _instance;
  LoggerService._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDB();
    return _db!;
  }

  Future<Database> _initDB() async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, 'clearpath.db');

    return openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        // Sessions table
        await db.execute('''
          CREATE TABLE sessions (
            id TEXT PRIMARY KEY,
            child_name TEXT NOT NULL,
            child_age INTEGER NOT NULL,
            start_time INTEGER NOT NULL,
            game1_complete INTEGER DEFAULT 0,
            game2_complete INTEGER DEFAULT 0,
            game3_complete INTEGER DEFAULT 0,
            dyslexia_risk REAL DEFAULT 0,
            adhd_risk REAL DEFAULT 0,
            autism_risk REAL DEFAULT 0
          )
        ''');

        // Events table — every tap timestamped
        await db.execute('''
          CREATE TABLE events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            game_id INTEGER NOT NULL,
            action_type TEXT NOT NULL,
            value REAL NOT NULL,
            metadata TEXT DEFAULT '',
            timestamp INTEGER NOT NULL,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
          )
        ''');

        // Features table — computed signals per session
        await db.execute('''
          CREATE TABLE features (
            session_id TEXT PRIMARY KEY,
            mean_response_time REAL DEFAULT 0,
            response_time_variance REAL DEFAULT 0,
            error_rate REAL DEFAULT 0,
            error_pattern_score REAL DEFAULT 0,
            retry_rate REAL DEFAULT 0,
            attention_drift_index REAL DEFAULT 0,
            impulsivity_score REAL DEFAULT 0,
            recovery_speed REAL DEFAULT 0,
            emotion_accuracy REAL DEFAULT 0,
            social_hesitation_time REAL DEFAULT 0,
            sequence_memory_score REAL DEFAULT 0,
            engagement_decay_rate REAL DEFAULT 0,
            FOREIGN KEY (session_id) REFERENCES sessions(id)
          )
        ''');
      },
    );
  }

  // ─── Session CRUD ───────────────────────────────────────────────

  Future<void> saveSession(SessionModel session) async {
    final db = await database;
    await db.insert(
      'sessions',
      {
        'id': session.id,
        'child_name': session.childName,
        'child_age': session.childAge,
        'start_time': session.startTime.millisecondsSinceEpoch,
        'game1_complete': session.game1Complete ? 1 : 0,
        'game2_complete': session.game2Complete ? 1 : 0,
        'game3_complete': session.game3Complete ? 1 : 0,
        'dyslexia_risk': session.dyslexiaRisk,
        'adhd_risk': session.adhdRisk,
        'autism_risk': session.autismRisk,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> updateSessionRisks(SessionModel session) async {
    final db = await database;
    await db.update(
      'sessions',
      {
        'game1_complete': session.game1Complete ? 1 : 0,
        'game2_complete': session.game2Complete ? 1 : 0,
        'game3_complete': session.game3Complete ? 1 : 0,
        'dyslexia_risk': session.dyslexiaRisk,
        'adhd_risk': session.adhdRisk,
        'autism_risk': session.autismRisk,
      },
      where: 'id = ?',
      whereArgs: [session.id],
    );
  }

  Future<List<Map<String, dynamic>>> getAllSessions() async {
    final db = await database;
    return db.query('sessions', orderBy: 'start_time DESC');
  }

  // ─── Event Logging ───────────────────────────────────────────────

  /// Log a single interaction event. Timestamped automatically.
  Future<void> logEvent(String sessionId, InteractionEvent event) async {
    final db = await database;
    await db.insert('events', {
      'session_id': sessionId,
      'game_id': event.gameId,
      'action_type': event.actionType,
      'value': event.value,
      'metadata': event.metadata ?? '',
      'timestamp': event.timestamp.millisecondsSinceEpoch,
    });
  }

  /// Batch insert events — more efficient for rapid tap sequences.
  Future<void> logEventBatch(
      String sessionId, List<InteractionEvent> events) async {
    final db = await database;
    final batch = db.batch();
    for (final event in events) {
      batch.insert('events', {
        'session_id': sessionId,
        'game_id': event.gameId,
        'action_type': event.actionType,
        'value': event.value,
        'metadata': event.metadata ?? '',
        'timestamp': event.timestamp.millisecondsSinceEpoch,
      });
    }
    await batch.commit(noResult: true);
  }

  Future<List<Map<String, dynamic>>> getEventsForSession(
      String sessionId) async {
    final db = await database;
    return db.query(
      'events',
      where: 'session_id = ?',
      whereArgs: [sessionId],
      orderBy: 'timestamp ASC',
    );
  }

  // ─── Feature Storage ───────────────────────────────────────────────

  Future<void> saveFeatures(
      String sessionId, Map<String, double> features) async {
    final db = await database;
    await db.insert(
      'features',
      {
        'session_id': sessionId,
        'mean_response_time': features['mean_response_time'] ?? 0,
        'response_time_variance': features['response_time_variance'] ?? 0,
        'error_rate': features['error_rate'] ?? 0,
        'error_pattern_score': features['error_pattern_score'] ?? 0,
        'retry_rate': features['retry_rate'] ?? 0,
        'attention_drift_index': features['attention_drift_index'] ?? 0,
        'impulsivity_score': features['impulsivity_score'] ?? 0,
        'recovery_speed': features['recovery_speed'] ?? 0,
        'emotion_accuracy': features['emotion_accuracy'] ?? 0,
        'social_hesitation_time': features['social_hesitation_time'] ?? 0,
        'sequence_memory_score': features['sequence_memory_score'] ?? 0,
        'engagement_decay_rate': features['engagement_decay_rate'] ?? 0,
      },
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  Future<void> closeDB() async {
    final db = await database;
    await db.close();
    _db = null;
  }
}
