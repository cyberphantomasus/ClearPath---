import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../models/session_model.dart';

/// Generates a detailed bilingual PDF screening report.
/// RTL Arabic layout with risk scores, signal breakdown, and referral guidance.
class PdfReportService {
  /// Generate the PDF and return the file path.
  static Future<String> generateReport(SessionModel session) async {
    final pdf = pw.Document();

    // Load Arabic font (Cairo) from assets
    // NOTE: Font files must be in assets/fonts/ — see pubspec.yaml
    // If fonts unavailable, falls back to Helvetica
    pw.Font? arabicFont;
    pw.Font? arabicFontBold;
    try {
      arabicFont = await PdfGoogleFonts.cairoRegular();
      arabicFontBold = await PdfGoogleFonts.cairoBold();
    } catch (_) {
      // Font load failed — use default
    }

    final baseStyle = pw.TextStyle(
      font: arabicFont,
      fontSize: 12,
      color: PdfColors.grey800,
    );
    final boldStyle = pw.TextStyle(
      font: arabicFontBold,
      fontSize: 12,
      fontWeight: pw.FontWeight.bold,
      color: PdfColors.grey900,
    );

    pdf.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        textDirection: pw.TextDirection.rtl,
        build: (context) => [
          _buildHeader(session, boldStyle),
          pw.SizedBox(height: 24),
          _buildSummaryBox(session, baseStyle, boldStyle),
          pw.SizedBox(height: 20),
          _buildRiskScores(session, baseStyle, boldStyle),
          pw.SizedBox(height: 20),
          _buildSignalBreakdown(session, baseStyle, boldStyle),
          pw.SizedBox(height: 20),
          _buildRecommendations(session, baseStyle, boldStyle),
          pw.SizedBox(height: 20),
          _buildDisclaimer(baseStyle),
          pw.SizedBox(height: 20),
          _buildFooter(boldStyle),
        ],
      ),
    );

    // Save to device storage
    final dir = await getApplicationDocumentsDirectory();
    final fileName =
        'clearpath_report_${session.childName.replaceAll(' ', '_')}_${DateTime.now().millisecondsSinceEpoch}.pdf';
    final file = File('${dir.path}/$fileName');
    await file.writeAsBytes(await pdf.save());
    return file.path;
  }

  // ─── Page Sections ────────────────────────────────────────────────

  static pw.Widget _buildHeader(SessionModel session, pw.TextStyle bold) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(20),
      decoration: pw.BoxDecoration(
        color: const PdfColor.fromInt(0xFF0A0E14),
        borderRadius: pw.BorderRadius.circular(12),
      ),
      child: pw.Row(
        mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
        children: [
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start,
            children: [
              pw.Text(
                'ClearPath — Screening Report',
                style: bold.copyWith(
                  fontSize: 20,
                  color: PdfColors.white,
                ),
              ),
              pw.SizedBox(height: 4),
              pw.Text(
                'University of Nahrain · AI & Robotics Engineering',
                style: pw.TextStyle(
                  fontSize: 10,
                  color: const PdfColor.fromInt(0xFF7A8FA8),
                ),
              ),
            ],
          ),
          pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.end,
            children: [
              pw.Text(
                'تقرير فحص التطور',
                style: bold.copyWith(
                  fontSize: 14,
                  color: const PdfColor.fromInt(0xFF3B82F6),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  static pw.Widget _buildSummaryBox(
      SessionModel session, pw.TextStyle base, pw.TextStyle bold) {
    final date = session.startTime;
    final dateStr =
        '${date.day}/${date.month}/${date.year}  ${date.hour}:${date.minute.toString().padLeft(2, '0')}';

    return pw.Container(
      padding: const pw.EdgeInsets.all(16),
      decoration: pw.BoxDecoration(
        border: pw.Border.all(color: const PdfColor.fromInt(0xFF1E2D44)),
        borderRadius: pw.BorderRadius.circular(10),
      ),
      child: pw.Row(
        children: [
          _infoCell('Child Name', session.childName, bold, base),
          pw.SizedBox(width: 40),
          _infoCell('Age', '${session.childAge} years', bold, base),
          pw.SizedBox(width: 40),
          _infoCell('Session Date', dateStr, bold, base),
          pw.SizedBox(width: 40),
          _infoCell(
              'Events Logged', '${session.events.length}', bold, base),
        ],
      ),
    );
  }

  static pw.Widget _infoCell(
      String label, String value, pw.TextStyle bold, pw.TextStyle base) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text(label,
            style:
                base.copyWith(fontSize: 9, color: const PdfColor.fromInt(0xFF7A8FA8))),
        pw.SizedBox(height: 2),
        pw.Text(value, style: bold.copyWith(fontSize: 13)),
      ],
    );
  }

  static pw.Widget _buildRiskScores(
      SessionModel session, pw.TextStyle base, pw.TextStyle bold) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('Risk Assessment Scores', style: bold.copyWith(fontSize: 15)),
        pw.SizedBox(height: 12),
        _riskBar(
          'Dyslexia Risk',
          'خطر عسر القراءة',
          session.dyslexiaRisk,
          const PdfColor.fromInt(0xFFA78BFA),
          bold,
          base,
        ),
        pw.SizedBox(height: 10),
        _riskBar(
          'ADHD Risk',
          'خطر اضطراب التركيز',
          session.adhdRisk,
          const PdfColor.fromInt(0xFFFB923C),
          bold,
          base,
        ),
        pw.SizedBox(height: 10),
        _riskBar(
          'Autism Spectrum Risk',
          'خطر طيف التوحد',
          session.autismRisk,
          const PdfColor.fromInt(0xFF34D399),
          bold,
          base,
        ),
      ],
    );
  }

  static pw.Widget _riskBar(
    String label,
    String arabicLabel,
    double score,
    PdfColor color,
    pw.TextStyle bold,
    pw.TextStyle base,
  ) {
    final pct = (score * 100).round();
    final level = score.riskLabel;

    return pw.Container(
      padding: const pw.EdgeInsets.all(14),
      decoration: pw.BoxDecoration(
        color: PdfColors.grey100,
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          pw.Row(
            mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
            children: [
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(label, style: bold.copyWith(fontSize: 13)),
                  pw.Text(arabicLabel,
                      style: base.copyWith(
                          fontSize: 10,
                          color: const PdfColor.fromInt(0xFF7A8FA8))),
                ],
              ),
              pw.Row(
                children: [
                  pw.Text('$pct%',
                      style: bold.copyWith(fontSize: 18, color: color)),
                  pw.SizedBox(width: 12),
                  pw.Container(
                    padding: const pw.EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: pw.BoxDecoration(
                      color: color.shade(0.2),
                      borderRadius: pw.BorderRadius.circular(100),
                    ),
                    child: pw.Text(level,
                        style: base.copyWith(fontSize: 9, color: color)),
                  ),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: 10),
          pw.Stack(
            children: [
              pw.Container(
                height: 8,
                decoration: pw.BoxDecoration(
                  color: PdfColors.grey300,
                  borderRadius: pw.BorderRadius.circular(4),
                ),
              ),
              pw.FractionallySizedBox(
                widthFactor: score.clamp(0.02, 1.0),
                child: pw.Container(
                  height: 8,
                  decoration: pw.BoxDecoration(
                    color: color,
                    borderRadius: pw.BorderRadius.circular(4),
                  ),
                ),
              ),
            ],
          ),
          pw.SizedBox(height: 8),
          pw.Text(score.riskDescription,
              style: base.copyWith(
                  fontSize: 10, color: const PdfColor.fromInt(0xFF555555))),
        ],
      ),
    );
  }

  static pw.Widget _buildSignalBreakdown(
      SessionModel session, pw.TextStyle base, pw.TextStyle bold) {
    if (session.features.isEmpty) return pw.SizedBox();

    final signals = [
      ('Mean Response Time', 'mean_response_time', 'ms'),
      ('Response Time Variance', 'response_time_variance', 'CoV'),
      ('Error Rate', 'error_rate', '%'),
      ('Error Pattern Score', 'error_pattern_score', ''),
      ('Retry Rate', 'retry_rate', ''),
      ('Attention Drift Index', 'attention_drift_index', ''),
      ('Impulsivity Score', 'impulsivity_score', ''),
      ('Recovery Speed', 'recovery_speed', 'x'),
      ('Emotion Accuracy', 'emotion_accuracy', '%'),
      ('Social Hesitation Time', 'social_hesitation_time', 'ms'),
      ('Sequence Memory Score', 'sequence_memory_score', ''),
      ('Engagement Decay Rate', 'engagement_decay_rate', ''),
    ];

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('Behavioral Signal Breakdown', style: bold.copyWith(fontSize: 15)),
        pw.SizedBox(height: 12),
        pw.Table(
          border: pw.TableBorder.all(
              color: const PdfColor.fromInt(0xFFE5E7EB), width: 0.5),
          children: [
            pw.TableRow(
              decoration:
                  const pw.BoxDecoration(color: PdfColor.fromInt(0xFFF3F4F6)),
              children: [
                _tableCell('Signal', bold, isHeader: true),
                _tableCell('Value', bold, isHeader: true),
              ],
            ),
            ...signals.map((sig) {
              final value = session.features[sig.$2] ?? 0.0;
              final unit = sig.$3;
              final displayValue = unit == 'ms'
                  ? '${value.round()} ms'
                  : unit == '%'
                      ? '${(value * 100).toStringAsFixed(1)}%'
                      : value.toStringAsFixed(3);
              return pw.TableRow(children: [
                _tableCell(sig.$1, base),
                _tableCell(displayValue, base),
              ]);
            }),
          ],
        ),
      ],
    );
  }

  static pw.Widget _tableCell(String text, pw.TextStyle style,
      {bool isHeader = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.all(8),
      child: pw.Text(
        text,
        style: isHeader ? style.copyWith(fontWeight: pw.FontWeight.bold) : style,
      ),
    );
  }

  static pw.Widget _buildRecommendations(
      SessionModel session, pw.TextStyle base, pw.TextStyle bold) {
    final recs = <String>[];

    if (session.dyslexiaRisk >= 0.65) {
      recs.add(
          'HIGH DYSLEXIA RISK: We recommend seeking evaluation from a specialist in reading and learning difficulties. Early intervention with structured literacy support can significantly improve outcomes.');
    } else if (session.dyslexiaRisk >= 0.35) {
      recs.add(
          'MODERATE DYSLEXIA INDICATORS: Consider sharing this report with your child\'s teacher. Additional reading support and monitoring is suggested.');
    }

    if (session.adhdRisk >= 0.65) {
      recs.add(
          'HIGH ADHD RISK: Please consult a pediatric specialist or child psychologist for a formal ADHD assessment. This screening is not a diagnosis but warrants professional follow-up.');
    } else if (session.adhdRisk >= 0.35) {
      recs.add(
          'MODERATE ATTENTION INDICATORS: Discuss with teachers and consider strategies for structured learning environments and regular breaks.');
    }

    if (session.autismRisk >= 0.65) {
      recs.add(
          'HIGH AUTISM SPECTRUM INDICATORS: We strongly recommend a formal assessment by a developmental pediatrician or child psychiatrist. Early support makes a profound difference.');
    } else if (session.autismRisk >= 0.35) {
      recs.add(
          'MODERATE SOCIAL COMMUNICATION INDICATORS: Observe social interactions at school and home. Share this report with your child\'s pediatrician at the next visit.');
    }

    if (recs.isEmpty) {
      recs.add(
          'LOW RISK ACROSS ALL SCREENED CONDITIONS: No significant indicators detected in this session. Continue to monitor your child\'s development normally. Repeat screening in 6 months or if concerns arise.');
    }

    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('Recommendations', style: bold.copyWith(fontSize: 15)),
        pw.SizedBox(height: 12),
        ...recs.map(
          (rec) => pw.Container(
            margin: const pw.EdgeInsets.only(bottom: 10),
            padding: const pw.EdgeInsets.all(14),
            decoration: pw.BoxDecoration(
              border: pw.Border(
                left: pw.BorderSide(
                  color: const PdfColor.fromInt(0xFF3B82F6),
                  width: 3,
                ),
              ),
              color: const PdfColor.fromInt(0xFFF0F7FF),
            ),
            child: pw.Text(rec, style: base.copyWith(fontSize: 11)),
          ),
        ),
      ],
    );
  }

  static pw.Widget _buildDisclaimer(pw.TextStyle base) {
    return pw.Container(
      padding: const pw.EdgeInsets.all(12),
      decoration: pw.BoxDecoration(
        color: const PdfColor.fromInt(0xFFFFF9E6),
        borderRadius: pw.BorderRadius.circular(8),
      ),
      child: pw.Text(
        'DISCLAIMER: ClearPath is a screening tool, not a diagnostic instrument. '
        'Results are based on behavioral patterns during a 10-minute interactive session and should not be '
        'used as a medical diagnosis. A trained professional must evaluate any concerns identified by this '
        'tool. This app is designed to help identify children who may benefit from professional assessment, '
        'particularly in areas where specialist access is limited.',
        style: base.copyWith(fontSize: 9, color: const PdfColor.fromInt(0xFF7A6000)),
      ),
    );
  }

  static pw.Widget _buildFooter(pw.TextStyle bold) {
    return pw.Row(
      mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
      children: [
        pw.Text(
          'ClearPath · University of Nahrain · AI & Robotics Engineering 2026',
          style: bold.copyWith(
              fontSize: 9, color: const PdfColor.fromInt(0xFF7A8FA8)),
        ),
        pw.Text(
          'Generated offline · No data transmitted',
          style: bold.copyWith(
              fontSize: 9, color: const PdfColor.fromInt(0xFF06D6A0)),
        ),
      ],
    );
  }
}
