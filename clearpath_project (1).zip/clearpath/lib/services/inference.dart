import 'package:tflite_flutter/tflite_flutter.dart';
import 'features.dart';
import '../models/session_model.dart';

/// Runs the three TFLite classifiers offline on-device.
/// Returns risk scores for Dyslexia, ADHD, and Autism Spectrum.
class InferenceService {
  static final InferenceService _instance = InferenceService._internal();
  factory InferenceService() => _instance;
  InferenceService._internal();

  Interpreter? _dyslexiaInterpreter;
  Interpreter? _adhdInterpreter;
  Interpreter? _autismInterpreter;

  bool _modelsLoaded = false;

  /// Load all three TFLite models from assets.
  /// Call once at app startup or before first inference.
  Future<void> loadModels() async {
    if (_modelsLoaded) return;

    try {
      _dyslexiaInterpreter = await Interpreter.fromAsset(
        'assets/models/dyslexia.tflite',
        options: InterpreterOptions()..threads = 2,
      );
      _adhdInterpreter = await Interpreter.fromAsset(
        'assets/models/adhd.tflite',
        options: InterpreterOptions()..threads = 2,
      );
      _autismInterpreter = await Interpreter.fromAsset(
        'assets/models/autism.tflite',
        options: InterpreterOptions()..threads = 2,
      );
      _modelsLoaded = true;
    } catch (e) {
      // Models may not exist yet during development — use fallback heuristics
      _modelsLoaded = false;
      rethrow;
    }
  }

  /// Run inference on a completed session.
  /// Populates session.dyslexiaRisk, adhdRisk, autismRisk.
  /// Returns a map of the three scores.
  Future<Map<String, double>> runInference(SessionModel session) async {
    // Extract the 12-signal feature vector
    final features = FeatureExtractor.extract(session);
    session.features = features;
    final vector = FeatureExtractor.toVector(features);

    if (!_modelsLoaded) {
      // Fallback: compute heuristic scores from features directly
      // Used during development before TFLite models are trained
      return _heuristicFallback(features);
    }

    final dyslexiaScore = await _runSingleModel(_dyslexiaInterpreter!, vector);
    final adhdScore = await _runSingleModel(_adhdInterpreter!, vector);
    final autismScore = await _runSingleModel(_autismInterpreter!, vector);

    session.dyslexiaRisk = dyslexiaScore;
    session.adhdRisk = adhdScore;
    session.autismRisk = autismScore;

    return {
      'dyslexia': dyslexiaScore,
      'adhd': adhdScore,
      'autism': autismScore,
    };
  }

  /// Run a single TFLite model on the 12-feature vector.
  Future<double> _runSingleModel(
      Interpreter interpreter, List<double> vector) async {
    // Input: [1, 12] float32 tensor
    // Output: [1, 2] softmax probabilities [prob_negative, prob_positive]
    final input = [vector]; // shape [1, 12]
    final output = List.filled(1 * 2, 0.0).reshape([1, 2]);

    interpreter.run(input, output);

    // Return the probability of the positive class (index 1)
    return (output as List<List<double>>)[0][1];
  }

  /// Heuristic fallback scores when TFLite models are not yet available.
  /// Based directly on the feature values — useful for UI testing.
  Map<String, double> _heuristicFallback(Map<String, double> f) {
    // Dyslexia: error pattern score + error rate + slow response time
    final dyslexia = _clamp(
      (f['error_pattern_score']! * 0.45) +
          (f['error_rate']! * 0.30) +
          (_normalizeResponseTime(f['mean_response_time']!) * 0.25),
    );

    // ADHD: impulsivity + attention drift + response time variance + engagement decay
    final adhdRaw = (f['impulsivity_score']! * 0.30) +
        (_negativeToPositive(f['attention_drift_index']!) * 0.25) +
        (f['response_time_variance']! * 0.25) +
        (f['engagement_decay_rate']! * 0.20);
    final adhd = _clamp(adhdRaw);

    // Autism: low emotion accuracy + high social hesitation + low sequence memory
    final autism = _clamp(
      ((1.0 - f['emotion_accuracy']!) * 0.45) +
          (_normalizeResponseTime(f['social_hesitation_time']!) * 0.30) +
          ((1.0 - f['sequence_memory_score']!) * 0.25),
    );

    return {
      'dyslexia': dyslexia,
      'adhd': adhd,
      'autism': autism,
    };
  }

  double _clamp(double v) => v.clamp(0.0, 1.0);

  // Normalize response time: 500ms → 0.0, 3000ms → 1.0
  double _normalizeResponseTime(double ms) =>
      _clamp((ms - 500) / 2500);

  // Convert negative drift to positive score
  double _negativeToPositive(double drift) =>
      _clamp(drift < 0 ? -drift : 0.0);

  void dispose() {
    _dyslexiaInterpreter?.close();
    _adhdInterpreter?.close();
    _autismInterpreter?.close();
    _modelsLoaded = false;
  }
}
