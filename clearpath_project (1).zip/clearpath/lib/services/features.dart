import '../models/session_model.dart';
import 'dart:math';

/// Computes all 12 behavioral signals from raw interaction events.
/// This Dart implementation mirrors the Python features.py logic exactly
/// so that on-device feature extraction matches what the model was trained on.
class FeatureExtractor {
  static const int _numSignals = 12;

  /// Main entry point. Returns a map of all 12 signals.
  static Map<String, double> extract(SessionModel session) {
    final allEvents = session.events;
    final g1 = session.eventsForGame(1);
    final g2 = session.eventsForGame(2);
    final g3 = session.eventsForGame(3);

    return {
      // Signal 1: Mean response time across all correct answers
      'mean_response_time': _meanResponseTime(allEvents),

      // Signal 2: Response time variance (coefficient of variation)
      'response_time_variance': _responseTimeVariance(allEvents),

      // Signal 3: Overall error rate
      'error_rate': _errorRate(allEvents),

      // Signal 4: Error pattern score — 0=random errors, 1=systematic (dyslexia)
      'error_pattern_score': _errorPatternScore(g1),

      // Signal 5: Retry rate after wrong answers
      'retry_rate': _retryRate(allEvents),

      // Signal 6: Attention drift — negative = drifting (ADHD)
      'attention_drift_index': _attentionDriftIndex(allEvents),

      // Signal 7: Impulsivity — false taps before target appears (Game 2)
      'impulsivity_score': _impulsivityScore(g2),

      // Signal 8: Recovery speed after distractors (Game 2)
      'recovery_speed': _recoverySpeed(g2),

      // Signal 9: Emotion recognition accuracy (Game 3)
      'emotion_accuracy': _emotionAccuracy(g3),

      // Signal 10: Social hesitation time (Game 3)
      'social_hesitation_time': _socialHesitationTime(g3),

      // Signal 11: Sequence memory score (Game 3)
      'sequence_memory_score': _sequenceMemoryScore(g3),

      // Signal 12: Engagement decay — taps/min first half vs second half
      'engagement_decay_rate': _engagementDecayRate(allEvents),
    };
  }

  /// Convert feature map to ordered float list for TFLite input.
  static List<double> toVector(Map<String, double> features) {
    return [
      features['mean_response_time'] ?? 0,
      features['response_time_variance'] ?? 0,
      features['error_rate'] ?? 0,
      features['error_pattern_score'] ?? 0,
      features['retry_rate'] ?? 0,
      features['attention_drift_index'] ?? 0,
      features['impulsivity_score'] ?? 0,
      features['recovery_speed'] ?? 0,
      features['emotion_accuracy'] ?? 0,
      features['social_hesitation_time'] ?? 0,
      features['sequence_memory_score'] ?? 0,
      features['engagement_decay_rate'] ?? 0,
    ];
  }

  // ─── Signal Implementations ────────────────────────────────────────

  /// Signal 1: mean(response_time_ms) across all correct answers
  static double _meanResponseTime(List<InteractionEvent> events) {
    final correct = events
        .where((e) => e.actionType == 'correct')
        .map((e) => e.value)
        .toList();
    if (correct.isEmpty) return 1500.0; // Default if no data
    return correct.reduce((a, b) => a + b) / correct.length;
  }

  /// Signal 2: std / mean (coefficient of variation) on response times
  static double _responseTimeVariance(List<InteractionEvent> events) {
    final correct = events
        .where((e) => e.actionType == 'correct')
        .map((e) => e.value)
        .toList();
    if (correct.length < 2) return 0.0;
    final mean = correct.reduce((a, b) => a + b) / correct.length;
    if (mean == 0) return 0.0;
    final variance =
        correct.map((t) => pow(t - mean, 2)).reduce((a, b) => a + b) /
            correct.length;
    final std = sqrt(variance);
    return std / mean; // CoV — higher = more variable (ADHD indicator)
  }

  /// Signal 3: wrong_answers / total_answers
  static double _errorRate(List<InteractionEvent> events) {
    final taps = events.where((e) =>
        e.actionType == 'correct' || e.actionType == 'wrong').toList();
    if (taps.isEmpty) return 0.0;
    final wrong = taps.where((e) => e.actionType == 'wrong').length;
    return wrong / taps.length;
  }

  /// Signal 4: count(repeated same error pair) / total_errors
  /// A score near 1.0 means the child makes the same mistake repeatedly — dyslexia marker.
  static double _errorPatternScore(List<InteractionEvent> g1Events) {
    final wrong = g1Events.where((e) => e.actionType == 'wrong').toList();
    if (wrong.length < 2) return 0.0;

    // Count how many wrong answers share the same metadata (same letter pair confused)
    final pairCounts = <String, int>{};
    for (final event in wrong) {
      final key = event.metadata ?? 'unknown';
      pairCounts[key] = (pairCounts[key] ?? 0) + 1;
    }

    // Repeated errors = pairs with count > 1
    final repeatedCount = pairCounts.values
        .where((count) => count > 1)
        .fold(0, (sum, count) => sum + count);

    return repeatedCount / wrong.length;
  }

  /// Signal 5: retries_after_wrong / total_wrong_answers
  static double _retryRate(List<InteractionEvent> events) {
    final wrong = events.where((e) => e.actionType == 'wrong').length;
    if (wrong == 0) return 0.0;
    final retries = events.where((e) => e.actionType == 'retry').length;
    return retries / wrong;
  }

  /// Signal 6: accuracy_last_quarter - accuracy_first_quarter
  /// Negative value = attention drifting over time (ADHD indicator)
  static double _attentionDriftIndex(List<InteractionEvent> events) {
    final taps = events
        .where((e) => e.actionType == 'correct' || e.actionType == 'wrong')
        .toList();
    if (taps.length < 8) return 0.0;

    final quarterSize = taps.length ~/ 4;
    final firstQuarter = taps.sublist(0, quarterSize);
    final lastQuarter = taps.sublist(taps.length - quarterSize);

    double accuracy(List<InteractionEvent> subset) {
      if (subset.isEmpty) return 0.0;
      return subset.where((e) => e.actionType == 'correct').length /
          subset.length;
    }

    return accuracy(lastQuarter) - accuracy(firstQuarter);
  }

  /// Signal 7: false_taps / (false_taps + correct_taps) from Game 2
  static double _impulsivityScore(List<InteractionEvent> g2Events) {
    final falseTaps = g2Events.where((e) => e.actionType == 'false_tap').length;
    final correctTaps = g2Events.where((e) => e.actionType == 'correct').length;
    final total = falseTaps + correctTaps;
    if (total == 0) return 0.0;
    return falseTaps / total;
  }

  /// Signal 8: mean(response_time after distractor) / baseline_response_time
  static double _recoverySpeed(List<InteractionEvent> g2Events) {
    final correct = g2Events.where((e) => e.actionType == 'correct').toList();
    if (correct.isEmpty) return 1.0;

    final baseline = correct.map((e) => e.value).reduce((a, b) => a + b) /
        correct.length;
    if (baseline == 0) return 1.0;

    // Events after a distractor tap
    final postDistractor = <double>[];
    for (int i = 0; i < g2Events.length - 1; i++) {
      if (g2Events[i].actionType == 'false_tap' &&
          g2Events[i + 1].actionType == 'correct') {
        postDistractor.add(g2Events[i + 1].value);
      }
    }

    if (postDistractor.isEmpty) return 1.0;
    final meanPostDistractor =
        postDistractor.reduce((a, b) => a + b) / postDistractor.length;
    return meanPostDistractor / baseline;
  }

  /// Signal 9: correct_emotion_matches / total_emotion_tasks (Game 3)
  static double _emotionAccuracy(List<InteractionEvent> g3Events) {
    final emotionTaps =
        g3Events.where((e) => e.actionType == 'emotion_select').toList();
    if (emotionTaps.isEmpty) return 0.5; // Neutral if no data
    final correct = emotionTaps.where((e) => e.value == 1.0).length;
    return correct / emotionTaps.length;
  }

  /// Signal 10: mean(response_time_ms) on social scenario questions only
  static double _socialHesitationTime(List<InteractionEvent> g3Events) {
    final socialEvents = g3Events
        .where((e) => e.actionType == 'social_response')
        .map((e) => e.value)
        .toList();
    if (socialEvents.isEmpty) return 1500.0;
    return socialEvents.reduce((a, b) => a + b) / socialEvents.length;
  }

  /// Signal 11: longest_correct_sequence / max_possible_sequence
  static double _sequenceMemoryScore(List<InteractionEvent> g3Events) {
    final sequenceEvents =
        g3Events.where((e) => e.actionType == 'sequence_tap').toList();
    if (sequenceEvents.isEmpty) return 0.0;

    int longestCorrect = 0;
    int currentStreak = 0;
    int maxPossible = 0;

    for (final event in sequenceEvents) {
      maxPossible++;
      if (event.value == 1.0) {
        currentStreak++;
        longestCorrect = max(longestCorrect, currentStreak);
      } else {
        currentStreak = 0;
      }
    }

    if (maxPossible == 0) return 0.0;
    return longestCorrect / maxPossible;
  }

  /// Signal 12: (taps/min first half - taps/min second half) / taps/min first half
  /// Positive value = engagement dropping (processing difficulty indicator)
  static double _engagementDecayRate(List<InteractionEvent> events) {
    final taps = events
        .where((e) => e.actionType == 'correct' || e.actionType == 'wrong')
        .toList();
    if (taps.length < 4) return 0.0;

    final midpoint = taps.length ~/ 2;
    final firstHalf = taps.sublist(0, midpoint);
    final secondHalf = taps.sublist(midpoint);

    if (firstHalf.isEmpty || secondHalf.isEmpty) return 0.0;

    // Duration of each half in minutes
    double durationMinutes(List<InteractionEvent> half) {
      if (half.length < 2) return 1.0;
      final durationMs = half.last.timestamp.millisecondsSinceEpoch -
          half.first.timestamp.millisecondsSinceEpoch;
      return max(durationMs / 60000.0, 0.001);
    }

    final firstRate = firstHalf.length / durationMinutes(firstHalf);
    final secondRate = secondHalf.length / durationMinutes(secondHalf);

    if (firstRate == 0) return 0.0;
    return (firstRate - secondRate) / firstRate;
  }
}
