import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'screens/home_screen.dart';
import 'screens/game1_screen.dart';
import 'screens/game2_screen.dart';
import 'screens/game3_screen.dart';
import 'screens/report_screen.dart';
import 'models/session_model.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ),
  );
  runApp(const ClearPathApp());
}

class ClearPathApp extends StatelessWidget {
  const ClearPathApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ClearPath',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.dark(),
      initialRoute: '/',
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const HomeScreen());
          case '/game1':
            final session = settings.arguments as SessionModel;
            return MaterialPageRoute(
              builder: (_) => Game1Screen(session: session),
            );
          case '/game2':
            final session = settings.arguments as SessionModel;
            return MaterialPageRoute(
              builder: (_) => Game2Screen(session: session),
            );
          case '/game3':
            final session = settings.arguments as SessionModel;
            return MaterialPageRoute(
              builder: (_) => Game3Screen(session: session),
            );
          case '/report':
            final session = settings.arguments as SessionModel;
            return MaterialPageRoute(
              builder: (_) => ReportScreen(session: session),
            );
          default:
            return MaterialPageRoute(builder: (_) => const HomeScreen());
        }
      },
    );
  }
}

class AppTheme {
  static ThemeData dark() {
    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: const Color(0xFF0A0E14),
      colorScheme: const ColorScheme.dark(
        primary: Color(0xFF3B82F6),
        secondary: Color(0xFF06D6A0),
        surface: Color(0xFF111620),
        error: Color(0xFFEF476F),
      ),
      textTheme: const TextTheme(
        displayLarge: TextStyle(
          fontFamily: 'AppFont',
          fontSize: 32,
          fontWeight: FontWeight.w700,
          color: Color(0xFFE8EDF5),
        ),
        headlineMedium: TextStyle(
          fontFamily: 'AppFont',
          fontSize: 22,
          fontWeight: FontWeight.w700,
          color: Color(0xFFE8EDF5),
        ),
        bodyLarge: TextStyle(
          fontFamily: 'AppFont',
          fontSize: 16,
          color: Color(0xFFE8EDF5),
        ),
        bodyMedium: TextStyle(
          fontFamily: 'AppFont',
          fontSize: 14,
          color: Color(0xFF7A8FA8),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF3B82F6),
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(14),
          ),
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 24),
          textStyle: const TextStyle(
            fontFamily: 'AppFont',
            fontSize: 16,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF182030),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF1E2D44)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF1E2D44)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: const BorderSide(color: Color(0xFF3B82F6), width: 2),
        ),
        labelStyle: const TextStyle(color: Color(0xFF7A8FA8)),
        hintStyle: const TextStyle(color: Color(0xFF3D5068)),
      ),
    );
  }
}

// App-wide color constants
class AppColors {
  static const bg = Color(0xFF0A0E14);
  static const surface = Color(0xFF111620);
  static const surface2 = Color(0xFF182030);
  static const border = Color(0xFF1E2D44);
  static const accent = Color(0xFF3B82F6);
  static const accent2 = Color(0xFF06D6A0);
  static const accent3 = Color(0xFFFFD166);
  static const accent4 = Color(0xFFEF476F);
  static const text = Color(0xFFE8EDF5);
  static const textDim = Color(0xFF7A8FA8);
  static const textMuted = Color(0xFF3D5068);
  static const dyslexia = Color(0xFFA78BFA);
  static const adhd = Color(0xFFFB923C);
  static const autism = Color(0xFF34D399);
}
