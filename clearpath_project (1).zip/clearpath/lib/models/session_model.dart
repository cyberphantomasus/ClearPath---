import 'package:uuid/uuid.dart';

/// Represents a single child screening session.
class SessionModel {
  final String id;
  final String childName;
  final int childAge;
  final DateTime startTime;

  // Raw interaction events collected during gameplay
  final List<InteractionEvent> events = [];

  // Computed feature vector (12 signals) — populated after session ends
  Map<String, double> features = {};

  // Risk scores from TFLite inference — populated after inference
  double dyslexiaRisk = 0.0;
  double adhdRisk = 0.0;
  double autismRisk = 0.0;

  // Which games have been completed
  bool game1Complete = false;
  bool game2Complete = false;
  bool game3Complete = false;

  SessionModel({
    required this.childName,
    required this.childAge,
  })  : id = const Uuid().v4(),
        startTime = DateTime.now();

  bool get allGamesComplete => game1Complete && game2Complete && game3Complete;

  void addEvent(InteractionEvent event) {
    events.add(event);
  }

  /// Returns all events for a specific game module.
  List<InteractionEvent> eventsForGame(int gameId) {
    return events.where((e) => e.gameId == gameId).toList();
  }
}

/// A single interaction event logged during gameplay.
class InteractionEvent {
  final int gameId;           // 1, 2, or 3
  final String actionType;    // 'tap', 'correct', 'wrong', 'retry', 'distractor_tap', 'emotion_select', 'gesture', 'false_tap'
  final double value;         // Response time in ms, or binary 0/1 depending on action
  final String? metadata;     // Optional — letter pair, emotion label, etc.
  final DateTime timestamp;

  InteractionEvent({
    required this.gameId,
    required this.actionType,
    required this.value,
    this.metadata,
  }) : timestamp = DateTime.now();

  Map<String, dynamic> toMap() => {
    'game_id': gameId,
    'action_type': actionType,
    'value': value,
    'metadata': metadata ?? '',
    'timestamp': timestamp.millisecondsSinceEpoch,
  };

  factory InteractionEvent.fromMap(Map<String, dynamic> map) {
    return InteractionEvent(
      gameId: map['game_id'] as int,
      actionType: map['action_type'] as String,
      value: (map['value'] as num).toDouble(),
      metadata: map['metadata'] as String?,
    );
  }
}

/// Risk level classification based on score.
enum RiskLevel { low, moderate, high }

extension RiskLevelExtension on double {
  RiskLevel get riskLevel {
    if (this < 0.35) return RiskLevel.low;
    if (this < 0.65) return RiskLevel.moderate;
    return RiskLevel.high;
  }

  String get riskLabel {
    switch (riskLevel) {
      case RiskLevel.low:
        return 'Low Risk';
      case RiskLevel.moderate:
        return 'Moderate Risk';
      case RiskLevel.high:
        return 'High Risk — Refer';
    }
  }

  String get riskDescription {
    switch (riskLevel) {
      case RiskLevel.low:
        return 'No significant indicators detected. Continue to monitor development normally.';
      case RiskLevel.moderate:
        return 'Some indicators present. Consider speaking with a teacher or school counselor.';
      case RiskLevel.high:
        return 'Strong indicators detected. We recommend seeking assessment from a specialist.';
    }
  }
}
