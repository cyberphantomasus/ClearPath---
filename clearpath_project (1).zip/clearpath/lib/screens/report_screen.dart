import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';
import 'dart:io';
import '../main.dart';
import '../models/session_model.dart';
import '../services/features.dart';
import '../services/inference.dart';
import '../services/logger.dart';
import '../services/pdf_service.dart';
import '../services/tts_service.dart';

class ReportScreen extends StatefulWidget {
  final SessionModel session;
  const ReportScreen({super.key, required this.session});

  @override
  State<ReportScreen> createState() => _ReportScreenState();
}

class _ReportScreenState extends State<ReportScreen>
    with TickerProviderStateMixin {
  final _inference = InferenceService();
  final _logger = LoggerService();
  final _tts = TtsService();

  bool _isProcessing = true;
  bool _pdfGenerating = false;
  String? _pdfPath;
  String _processingStep = 'Extracting behavioral signals...';

  late AnimationController _fadeCtrl;
  late AnimationController _scoresCtrl;

  @override
  void initState() {
    super.initState();
    _fadeCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 500));
    _scoresCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 1000));
    _runInference();
  }

  Future<void> _runInference() async {
    // Step 1: Extract features
    setState(() => _processingStep = 'Extracting 12 behavioral signals...');
    await Future.delayed(const Duration(milliseconds: 600));

    final features = FeatureExtractor.extract(widget.session);
    widget.session.features = features;
    await _logger.saveFeatures(widget.session.id, features);

    // Step 2: Run models
    setState(() => _processingStep = 'Running AI classifiers...');
    await Future.delayed(const Duration(milliseconds: 400));

    try {
      await _inference.loadModels();
    } catch (_) {
      // Models not available yet — will use heuristic fallback
    }

    final scores = await _inference.runInference(widget.session);
    widget.session.dyslexiaRisk = scores['dyslexia'] ?? 0.0;
    widget.session.adhdRisk = scores['adhd'] ?? 0.0;
    widget.session.autismRisk = scores['autism'] ?? 0.0;

    // Step 3: Save results
    setState(() => _processingStep = 'Saving results...');
    await _logger.updateSessionRisks(widget.session);

    setState(() {
      _isProcessing = false;
      _processingStep = 'Done!';
    });

    _fadeCtrl.forward();
    _scoresCtrl.forward();

    _tts.speak(TtsService.sessionComplete);
  }

  Future<void> _generatePdf() async {
    setState(() => _pdfGenerating = true);
    try {
      final path = await PdfReportService.generateReport(widget.session);
      setState(() {
        _pdfPath = path;
        _pdfGenerating = false;
      });
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('PDF report saved to device'),
            backgroundColor: AppColors.accent2,
          ),
        );
      }
    } catch (e) {
      setState(() => _pdfGenerating = false);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('PDF error: $e'),
            backgroundColor: AppColors.accent4,
          ),
        );
      }
    }
  }

  Future<void> _sharePdf() async {
    if (_pdfPath == null) {
      await _generatePdf();
      if (_pdfPath == null) return;
    }
    await Share.shareXFiles(
      [XFile(_pdfPath!)],
      text: 'ClearPath Screening Report — ${widget.session.childName}',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: _isProcessing ? _buildProcessing() : _buildReport(),
      ),
    );
  }

  Widget _buildProcessing() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: 60,
            height: 60,
            child: CircularProgressIndicator(
              strokeWidth: 3,
              valueColor: const AlwaysStoppedAnimation(AppColors.accent),
            ),
          ),
          const SizedBox(height: 24),
          const Text('Analyzing Session',
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text)),
          const SizedBox(height: 8),
          Text(_processingStep,
              style: const TextStyle(color: AppColors.textDim, fontSize: 14)),
          const SizedBox(height: 32),
          Text(
            '${widget.session.events.length} events recorded',
            style: const TextStyle(
                color: AppColors.accent,
                fontFamily: 'monospace',
                fontSize: 13),
          ),
        ],
      ),
    );
  }

  Widget _buildReport() {
    return FadeTransition(
      opacity: _fadeCtrl,
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildReportHeader(),
            const SizedBox(height: 24),
            _buildRiskCards(),
            const SizedBox(height: 20),
            _buildSignalsGrid(),
            const SizedBox(height: 20),
            _buildRecommendations(),
            const SizedBox(height: 20),
            _buildActions(),
            const SizedBox(height: 20),
            _buildDisclaimer(),
            const SizedBox(height: 32),
          ],
        ),
      ),
    );
  }

  Widget _buildReportHeader() {
    final date = widget.session.startTime;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.accent2.withOpacity(0.12),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.assessment_rounded,
                  color: AppColors.accent2, size: 24),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('Screening Report',
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        color: AppColors.text)),
                const Text('تقرير الفحص',
                    style: TextStyle(color: AppColors.textDim, fontSize: 12)),
              ],
            ),
          ],
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppColors.border),
          ),
          child: Row(
            children: [
              _infoItem('Child', widget.session.childName),
              _infoItem('Age', '${widget.session.childAge} yrs'),
              _infoItem(
                  'Date',
                  '${date.day}/${date.month}/${date.year}'),
              _infoItem('Events', '${widget.session.events.length}'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _infoItem(String label, String value) {
    return Expanded(
      child: Column(
        children: [
          Text(label,
              style: const TextStyle(
                  color: AppColors.textDim,
                  fontSize: 10,
                  fontWeight: FontWeight.w500)),
          const SizedBox(height: 2),
          Text(value,
              style: const TextStyle(
                  color: AppColors.text,
                  fontSize: 13,
                  fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  Widget _buildRiskCards() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Risk Assessment',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.text)),
        const SizedBox(height: 12),
        _riskCard(
          'Dyslexia',
          'عسر القراءة',
          widget.session.dyslexiaRisk,
          AppColors.dyslexia,
          Icons.text_fields_rounded,
          'Based on letter error patterns, response time, and systematic confusion',
        ),
        const SizedBox(height: 10),
        _riskCard(
          'ADHD',
          'اضطراب التركيز',
          widget.session.adhdRisk,
          AppColors.adhd,
          Icons.center_focus_strong_rounded,
          'Based on impulsivity, attention drift, and response time variance',
        ),
        const SizedBox(height: 10),
        _riskCard(
          'Autism Spectrum',
          'طيف التوحد',
          widget.session.autismRisk,
          AppColors.autism,
          Icons.face_rounded,
          'Based on emotion recognition, social hesitation, and sequence memory',
        ),
      ],
    );
  }

  Widget _riskCard(
    String label,
    String arabicLabel,
    double score,
    Color color,
    IconData icon,
    String basis,
  ) {
    final pct = (score * 100).round();
    final level = score.riskLevel;

    return AnimatedBuilder(
      animation: _scoresCtrl,
      builder: (_, __) {
        final animatedScore = score * _scoresCtrl.value;
        return Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(
              color: level == RiskLevel.high
                  ? color.withOpacity(0.4)
                  : AppColors.border,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 36,
                    height: 36,
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.12),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Icon(icon, color: color, size: 20),
                  ),
                  const SizedBox(width: 10),
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(label,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 15,
                              color: AppColors.text)),
                      Text(arabicLabel,
                          style: const TextStyle(
                              color: AppColors.textDim, fontSize: 11)),
                    ],
                  ),
                  const Spacer(),
                  Text('$pct%',
                      style: TextStyle(
                          color: color,
                          fontSize: 24,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'monospace')),
                  const SizedBox(width: 8),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 8, vertical: 3),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(100),
                    ),
                    child: Text(score.riskLabel,
                        style: TextStyle(
                            color: color,
                            fontSize: 10,
                            fontWeight: FontWeight.w700)),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: animatedScore.clamp(0.0, 1.0),
                  backgroundColor: AppColors.surface2,
                  valueColor: AlwaysStoppedAnimation(color),
                  minHeight: 8,
                ),
              ),
              const SizedBox(height: 8),
              Text(basis,
                  style: const TextStyle(
                      color: AppColors.textMuted, fontSize: 11)),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSignalsGrid() {
    if (widget.session.features.isEmpty) return const SizedBox();

    final signals = [
      ('Response Time', 'mean_response_time', 'ms', true),
      ('Time Variance', 'response_time_variance', 'CoV', false),
      ('Error Rate', 'error_rate', '%', false),
      ('Error Pattern', 'error_pattern_score', '', false),
      ('Retry Rate', 'retry_rate', '', false),
      ('Attention Drift', 'attention_drift_index', '', false),
      ('Impulsivity', 'impulsivity_score', '', false),
      ('Recovery Speed', 'recovery_speed', 'x', false),
      ('Emotion Accuracy', 'emotion_accuracy', '%', true),
      ('Social Hesitation', 'social_hesitation_time', 'ms', true),
      ('Sequence Memory', 'sequence_memory_score', '', true),
      ('Engagement Decay', 'engagement_decay_rate', '', false),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('12 Behavioral Signals',
            style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.text)),
        const SizedBox(height: 12),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            childAspectRatio: 2.2,
          ),
          itemCount: signals.length,
          itemBuilder: (_, i) {
            final sig = signals[i];
            final value = widget.session.features[sig.$2] ?? 0.0;
            final unit = sig.$3;
            final higherIsBetter = sig.$4;
            final displayValue = unit == 'ms'
                ? '${value.round()}'
                : unit == '%'
                    ? '${(value * 100).toStringAsFixed(0)}%'
                    : value.toStringAsFixed(2);

            return Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.surface,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppColors.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(sig.$1,
                      style: const TextStyle(
                          color: AppColors.textDim,
                          fontSize: 10,
                          fontWeight: FontWeight.w500),
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        displayValue,
                        style: const TextStyle(
                          color: AppColors.text,
                          fontSize: 16,
                          fontWeight: FontWeight.w700,
                          fontFamily: 'monospace',
                        ),
                      ),
                      if (unit.isNotEmpty)
                        Text(unit,
                            style: const TextStyle(
                                color: AppColors.textMuted, fontSize: 10)),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildRecommendations() {
    final recs = <({String title, String body, Color color})>[];

    if (widget.session.dyslexiaRisk >= 0.65) {
      recs.add((
        title: 'Dyslexia — High Risk',
        body:
            'Seek evaluation from a reading specialist. Structured literacy support before age 8 dramatically improves outcomes.',
        color: AppColors.dyslexia,
      ));
    } else if (widget.session.dyslexiaRisk >= 0.35) {
      recs.add((
        title: 'Dyslexia — Monitor',
        body: 'Share this report with the child\'s teacher. Additional reading support is suggested.',
        color: AppColors.dyslexia,
      ));
    }

    if (widget.session.adhdRisk >= 0.65) {
      recs.add((
        title: 'ADHD — High Risk',
        body:
            'Consult a pediatric specialist for formal ADHD assessment. This screening is not a diagnosis.',
        color: AppColors.adhd,
      ));
    } else if (widget.session.adhdRisk >= 0.35) {
      recs.add((
        title: 'ADHD — Monitor',
        body: 'Discuss structured learning strategies with teachers. Regular breaks and clear routines help.',
        color: AppColors.adhd,
      ));
    }

    if (widget.session.autismRisk >= 0.65) {
      recs.add((
        title: 'Autism Spectrum — High Risk',
        body:
            'Seek formal assessment by a developmental pediatrician. Early support profoundly improves outcomes.',
        color: AppColors.autism,
      ));
    } else if (widget.session.autismRisk >= 0.35) {
      recs.add((
        title: 'Autism Spectrum — Monitor',
        body: 'Observe social interactions at school and home. Share this report with your pediatrician.',
        color: AppColors.autism,
      ));
    }

    if (recs.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.accent2.withOpacity(0.06),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.accent2.withOpacity(0.2)),
        ),
        child: Row(
          children: [
            const Icon(Icons.check_circle_rounded,
                color: AppColors.accent2, size: 24),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Low Risk — No Significant Indicators',
                      style: TextStyle(
                          fontWeight: FontWeight.w600,
                          color: AppColors.accent2,
                          fontSize: 14)),
                  const SizedBox(height: 4),
                  Text(
                    'No concerning patterns detected. Continue to monitor development normally. Repeat screening in 6 months or if new concerns arise.',
                    style: const TextStyle(
                        color: AppColors.textDim, fontSize: 12),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recommendations',
            style: TextStyle(
                fontSize: 16, fontWeight: FontWeight.w600, color: AppColors.text)),
        const SizedBox(height: 10),
        ...recs.map(
          (r) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: r.color.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12),
              border: Border(
                  left: BorderSide(color: r.color, width: 3)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(r.title,
                    style: TextStyle(
                        color: r.color,
                        fontWeight: FontWeight.w700,
                        fontSize: 13)),
                const SizedBox(height: 4),
                Text(r.body,
                    style: const TextStyle(
                        color: AppColors.textDim, fontSize: 13)),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildActions() {
    return Column(
      children: [
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            onPressed: _pdfGenerating ? null : _generatePdf,
            icon: _pdfGenerating
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(
                        strokeWidth: 2, color: Colors.white))
                : const Icon(Icons.picture_as_pdf_rounded),
            label: Text(
                _pdfGenerating ? 'Generating...' : 'Generate PDF Report'),
          ),
        ),
        if (_pdfPath != null) ...[
          const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _sharePdf,
              icon: const Icon(Icons.share_rounded),
              label: const Text('Share Report'),
              style: OutlinedButton.styleFrom(
                foregroundColor: AppColors.accent,
                side: const BorderSide(color: AppColors.border),
                padding: const EdgeInsets.symmetric(vertical: 14),
              ),
            ),
          ),
        ],
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: TextButton(
            onPressed: () =>
                Navigator.pushNamedAndRemoveUntil(context, '/', (_) => false),
            child: const Text('New Screening',
                style: TextStyle(color: AppColors.textDim)),
          ),
        ),
      ],
    );
  }

  Widget _buildDisclaimer() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppColors.surface2,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: AppColors.border),
      ),
      child: const Text(
        'DISCLAIMER: ClearPath is a screening tool, not a diagnostic instrument. Results are based on behavioral patterns and should not be used as a medical diagnosis. Always consult a qualified professional. This app operates fully offline — no data is transmitted.',
        style: TextStyle(
            color: AppColors.textMuted, fontSize: 11, height: 1.5),
      ),
    );
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _scoresCtrl.dispose();
    super.dispose();
  }
}
