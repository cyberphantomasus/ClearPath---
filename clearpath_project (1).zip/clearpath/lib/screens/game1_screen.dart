import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';

/// Game 1 — Arabic Letter Matching
/// Screens for Dyslexia by measuring:
///   - Letter reversal errors (systematic confusion between similar Arabic letters)
///   - Response time per task
///   - Error pattern score (repeated same-pair mistakes = systematic, not random)
///   - Retry behavior
///   - Performance decay over session

class Game1Screen extends StatefulWidget {
  final SessionModel session;
  const Game1Screen({super.key, required this.session});

  @override
  State<Game1Screen> createState() => _Game1ScreenState();
}

class _Game1ScreenState extends State<Game1Screen>
    with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _random = Random();

  // Arabic letter groups — visually similar pairs are dyslexia markers
  // Each group contains the target and similar-looking distractors
  static const _letterGroups = [
    // Group A — dots on top/bottom similar letters
    ['ب', 'ت', 'ث', 'ن'],
    // Group B — curved letters
    ['ج', 'ح', 'خ'],
    // Group C — baseline similar
    ['د', 'ذ', 'ر', 'ز'],
    // Group D — open top
    ['س', 'ش'],
    // Group E — similar body
    ['ع', 'غ'],
    // Group F — dots
    ['ف', 'ق'],
    // Group G — vertical strokes
    ['ك', 'ل'],
    // Group H — round
    ['م', 'ن', 'ه'],
    // Group I — connecting
    ['و', 'ي'],
  ];

  static const _totalRounds = 20;
  static const _gameDurationSeconds = 120;

  int _currentRound = 0;
  String _targetLetter = '';
  List<String> _gridLetters = [];
  int _correctCount = 0;
  int _wrongCount = 0;
  int _retryCount = 0;
  bool _lastWasWrong = false;
  DateTime? _roundStartTime;
  int _timeRemaining = _gameDurationSeconds;
  Timer? _timer;
  bool _gameOver = false;
  int? _selectedIndex;
  bool _showFeedback = false;
  bool _lastAnswerCorrect = false;

  late AnimationController _feedbackCtrl;
  late AnimationController _letterCtrl;

  @override
  void initState() {
    super.initState();
    _feedbackCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 300));
    _letterCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
    _startGame();
  }

  void _startGame() {
    _tts.speak(TtsService.game1Intro);
    _startTimer();
    _nextRound();
  }

  void _startTimer() {
    _timer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_timeRemaining <= 0 || _currentRound >= _totalRounds) {
        _endGame();
        return;
      }
      setState(() => _timeRemaining--);
    });
  }

  void _nextRound() {
    if (_currentRound >= _totalRounds || _timeRemaining <= 0) {
      _endGame();
      return;
    }

    // Pick a random letter group and select target + distractors
    final group = _letterGroups[_random.nextInt(_letterGroups.length)];
    final targetIdx = _random.nextInt(group.length);
    final target = group[targetIdx];

    // Build 6-letter grid — target appears once, rest are distractors from same group + others
    final Set<String> grid = {target};
    // Add distractors from same group (similar-looking — dyslexia relevant)
    for (final l in group) {
      if (l != target && grid.length < 5) grid.add(l);
    }
    // Fill remaining with random letters from other groups
    while (grid.length < 6) {
      final g = _letterGroups[_random.nextInt(_letterGroups.length)];
      grid.add(g[_random.nextInt(g.length)]);
    }

    final shuffled = grid.toList()..shuffle(_random);

    setState(() {
      _targetLetter = target;
      _gridLetters = shuffled;
      _selectedIndex = null;
      _showFeedback = false;
      _roundStartTime = DateTime.now();
    });

    _letterCtrl.forward(from: 0);
  }

  void _onLetterTap(int idx) async {
    if (_showFeedback || _gameOver) return;

    final responseTime = DateTime.now()
        .difference(_roundStartTime!)
        .inMilliseconds
        .toDouble();

    final tappedLetter = _gridLetters[idx];
    final isCorrect = tappedLetter == _targetLetter;

    setState(() {
      _selectedIndex = idx;
      _showFeedback = true;
      _lastAnswerCorrect = isCorrect;
    });

    if (isCorrect) {
      _correctCount++;
      final event = InteractionEvent(
        gameId: 1,
        actionType: 'correct',
        value: responseTime,
        metadata: _targetLetter,
      );
      widget.session.addEvent(event);
      await _logger.logEvent(widget.session.id, event);

      if (_lastWasWrong) {
        // This tap after a wrong answer is a retry
        _retryCount++;
        final retryEvent = InteractionEvent(
          gameId: 1,
          actionType: 'retry',
          value: responseTime,
          metadata: _targetLetter,
        );
        widget.session.addEvent(retryEvent);
        await _logger.logEvent(widget.session.id, retryEvent);
      }

      _lastWasWrong = false;
      _tts.speak(TtsService.wellDone);

      await Future.delayed(const Duration(milliseconds: 600));
      _currentRound++;
      _nextRound();
    } else {
      // Wrong answer — log with the pair info (target + what they tapped)
      // This metadata is key for error pattern score
      _wrongCount++;
      _lastWasWrong = true;

      final event = InteractionEvent(
        gameId: 1,
        actionType: 'wrong',
        value: responseTime,
        metadata: '${_targetLetter}_$tappedLetter', // pair info for pattern score
      );
      widget.session.addEvent(event);
      await _logger.logEvent(widget.session.id, event);

      _tts.speak(TtsService.tryAgain);

      // Keep grid visible so child can retry — don't advance round
      await Future.delayed(const Duration(milliseconds: 800));
      setState(() {
        _selectedIndex = null;
        _showFeedback = false;
        // Reset timer for this round but same letters
        _roundStartTime = DateTime.now();
      });
    }
  }

  void _endGame() async {
    _timer?.cancel();
    setState(() => _gameOver = true);
    widget.session.game1Complete = true;
    await _logger.updateSessionRisks(widget.session);
    await Future.delayed(const Duration(milliseconds: 1000));
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/game2',
          arguments: widget.session);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              _buildProgressBar(),
              const SizedBox(height: 20),
              _buildRoundHeader(),
              const SizedBox(height: 24),
              _buildTargetLetter(),
              const SizedBox(height: 24),
              _buildInstruction(),
              const SizedBox(height: 20),
              Expanded(child: _buildLetterGrid()),
              _buildStats(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProgressBar() {
    final progress = _currentRound / _totalRounds;
    final timeProgress = _timeRemaining / _gameDurationSeconds;
    return Column(
      children: [
        Row(
          children: [
            const Text('Game 1 of 3',
                style: TextStyle(
                    color: AppColors.textDim,
                    fontSize: 12,
                    fontWeight: FontWeight.w500)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.dyslexia.withOpacity(0.1),
                borderRadius: BorderRadius.circular(100),
              ),
              child: const Text('Dyslexia Screen',
                  style: TextStyle(
                      color: AppColors.dyslexia,
                      fontSize: 11,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: progress,
            backgroundColor: AppColors.surface2,
            valueColor: const AlwaysStoppedAnimation(AppColors.dyslexia),
            minHeight: 4,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          children: [
            Icon(Icons.timer_outlined,
                size: 13,
                color: _timeRemaining < 20
                    ? AppColors.accent4
                    : AppColors.textDim),
            const SizedBox(width: 4),
            Text(
              '${_timeRemaining}s',
              style: TextStyle(
                color: _timeRemaining < 20
                    ? AppColors.accent4
                    : AppColors.textDim,
                fontSize: 12,
                fontFamily: 'monospace',
              ),
            ),
            const Spacer(),
            Text('Round ${_currentRound + 1} / $_totalRounds',
                style: const TextStyle(
                    color: AppColors.textDim, fontSize: 12)),
          ],
        ),
      ],
    );
  }

  Widget _buildRoundHeader() {
    return const Text(
      'Letter Matching',
      style: TextStyle(
        fontSize: 20,
        fontWeight: FontWeight.w700,
        color: AppColors.text,
      ),
    );
  }

  Widget _buildTargetLetter() {
    return Column(
      children: [
        const Text('Find this letter:',
            style: TextStyle(color: AppColors.textDim, fontSize: 13)),
        const SizedBox(height: 12),
        Container(
          width: 90,
          height: 90,
          decoration: BoxDecoration(
            color: AppColors.dyslexia.withOpacity(0.1),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.dyslexia.withOpacity(0.4), width: 2),
          ),
          child: Center(
            child: Text(
              _targetLetter,
              style: const TextStyle(
                fontSize: 52,
                color: AppColors.text,
                height: 1,
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          'اضغط على الحرف المطابق',
          style: TextStyle(
            color: AppColors.dyslexia.withOpacity(0.7),
            fontSize: 13,
          ),
        ),
      ],
    );
  }

  Widget _buildInstruction() {
    return const Text(
      'Tap the matching letter in the grid below',
      style: TextStyle(color: AppColors.textDim, fontSize: 13),
      textAlign: TextAlign.center,
    );
  }

  Widget _buildLetterGrid() {
    return GridView.builder(
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.0,
      ),
      itemCount: _gridLetters.length,
      itemBuilder: (_, idx) {
        final letter = _gridLetters[idx];
        final isSelected = idx == _selectedIndex;
        final isTarget = letter == _targetLetter;

        Color borderColor = AppColors.border;
        Color bgColor = AppColors.surface2;
        Color textColor = AppColors.text;

        if (isSelected && _showFeedback) {
          if (_lastAnswerCorrect) {
            borderColor = AppColors.accent2;
            bgColor = AppColors.accent2.withOpacity(0.15);
          } else {
            borderColor = AppColors.accent4;
            bgColor = AppColors.accent4.withOpacity(0.12);
          }
        }

        return GestureDetector(
          onTap: () => _onLetterTap(idx),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 150),
            decoration: BoxDecoration(
              color: bgColor,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: borderColor, width: 1.5),
            ),
            child: Center(
              child: Text(
                letter,
                style: TextStyle(
                  fontSize: 40,
                  color: textColor,
                  height: 1,
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildStats() {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _statChip(Icons.check_circle_outline, '$_correctCount', AppColors.accent2),
          const SizedBox(width: 12),
          _statChip(Icons.cancel_outlined, '$_wrongCount', AppColors.accent4),
          const SizedBox(width: 12),
          _statChip(Icons.refresh_rounded, '$_retryCount', AppColors.accent3),
        ],
      ),
    );
  }

  Widget _statChip(IconData icon, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 4),
          Text(value, style: TextStyle(color: color, fontSize: 13, fontWeight: FontWeight.w600)),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _feedbackCtrl.dispose();
    _letterCtrl.dispose();
    super.dispose();
  }
}
