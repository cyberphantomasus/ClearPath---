import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';

/// Game 3 — Social Pattern Recognition
/// Screens for Autism Spectrum by measuring:
///   - Emotion recognition accuracy
///   - Social hesitation time (pause before answering social questions)
///   - Mirror task accuracy (reproduce a social gesture)
///   - Sequence memory (social gesture sequence)
///   - Preference for mechanical vs social stimuli

class Game3Screen extends StatefulWidget {
  final SessionModel session;
  const Game3Screen({super.key, required this.session});

  @override
  State<Game3Screen> createState() => _Game3ScreenState();
}

class _Game3ScreenState extends State<Game3Screen>
    with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _random = Random();

  // Emotion recognition tasks
  static const _emotions = [
    (emoji: '😊', label: 'Happy', options: ['Happy', 'Sad', 'Angry', 'Surprised']),
    (emoji: '😢', label: 'Sad', options: ['Happy', 'Sad', 'Scared', 'Tired']),
    (emoji: '😠', label: 'Angry', options: ['Happy', 'Angry', 'Surprised', 'Sad']),
    (emoji: '😨', label: 'Scared', options: ['Happy', 'Scared', 'Angry', 'Surprised']),
    (emoji: '😴', label: 'Tired', options: ['Happy', 'Tired', 'Sad', 'Bored']),
    (emoji: '🤩', label: 'Excited', options: ['Excited', 'Happy', 'Scared', 'Surprised']),
    (emoji: '🥺', label: 'Worried', options: ['Happy', 'Worried', 'Sad', 'Angry']),
    (emoji: '😐', label: 'Neutral', options: ['Happy', 'Neutral', 'Sad', 'Tired']),
  ];

  // Gesture sequences for mirror task
  static const _gestures = [
    ['👋', '✊', '✌️'],
    ['✊', '✌️', '👋'],
    ['✌️', '👋', '✊'],
    ['👋', '✌️', '✊', '👋'],
    ['✊', '👋', '✌️', '✊'],
  ];

  int _round = 0;
  static const _totalRounds = 16;
  String _currentTaskType = 'emotion'; // 'emotion', 'social', 'sequence'
  DateTime? _roundStartTime;
  bool _showFeedback = false;
  bool _lastCorrect = false;
  bool _gameOver = false;
  int _correctCount = 0;
  int _wrongCount = 0;

  // Emotion task state
  dynamic _currentEmotion;
  List<String> _shuffledOptions = [];

  // Sequence task state
  List<String> _currentSequence = [];
  List<String> _playerSequence = [];
  bool _showingSequence = true;
  int _sequenceIndex = 0;
  Timer? _sequenceTimer;

  late AnimationController _bounceCtrl;
  late AnimationController _fadeCtrl;

  @override
  void initState() {
    super.initState();
    _bounceCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 300),
    );
    _tts.speak(TtsService.game3Intro);
    Future.delayed(const Duration(seconds: 2), _nextRound);
  }

  void _nextRound() {
    if (_round >= _totalRounds || _gameOver) {
      _endGame();
      return;
    }

    _fadeCtrl.forward(from: 0);

    // Cycle through task types
    final taskIndex = _round % 3;
    setState(() {
      _showFeedback = false;
      _roundStartTime = DateTime.now();

      if (taskIndex == 0 || taskIndex == 1) {
        _currentTaskType = 'emotion';
        _currentEmotion = _emotions[_random.nextInt(_emotions.length)];
        _shuffledOptions = List.from(_currentEmotion.options)..shuffle(_random);
      } else {
        _currentTaskType = 'sequence';
        final seq = _gestures[_random.nextInt(_gestures.length)];
        _currentSequence = List.from(seq);
        _playerSequence = [];
        _showingSequence = true;
        _sequenceIndex = 0;
        _playSequence();
      }
    });
  }

  void _playSequence() {
    _sequenceTimer?.cancel();
    int i = 0;
    _sequenceTimer = Timer.periodic(const Duration(milliseconds: 700), (t) {
      if (i < _currentSequence.length) {
        setState(() => _sequenceIndex = i);
        i++;
      } else {
        t.cancel();
        setState(() => _showingSequence = false);
      }
    });
  }

  void _onEmotionSelected(String selected) async {
    if (_showFeedback) return;

    final responseTime =
        DateTime.now().difference(_roundStartTime!).inMilliseconds.toDouble();
    final isCorrect = selected == _currentEmotion.label;

    setState(() {
      _showFeedback = true;
      _lastCorrect = isCorrect;
    });

    if (isCorrect) _correctCount++;
    else _wrongCount++;

    final event = InteractionEvent(
      gameId: 3,
      actionType: 'emotion_select',
      value: isCorrect ? 1.0 : 0.0,
      metadata: '${_currentEmotion.label}_$selected',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    // Also log as social_response if it's a social scenario question
    if (_round % 3 == 1) {
      final socialEvent = InteractionEvent(
        gameId: 3,
        actionType: 'social_response',
        value: responseTime,
      );
      widget.session.addEvent(socialEvent);
      await _logger.logEvent(widget.session.id, socialEvent);
    }

    if (isCorrect) _tts.speak(TtsService.wellDone);
    else _tts.speak(TtsService.tryAgain);

    await Future.delayed(const Duration(milliseconds: 1000));
    _round++;
    _nextRound();
  }

  void _onSequenceGestureTap(String gesture) async {
    if (_showingSequence || _showFeedback) return;

    final responseTime =
        DateTime.now().difference(_roundStartTime!).inMilliseconds.toDouble();

    _playerSequence.add(gesture);

    final idx = _playerSequence.length - 1;
    final isCorrect = idx < _currentSequence.length &&
        _playerSequence[idx] == _currentSequence[idx];

    final event = InteractionEvent(
      gameId: 3,
      actionType: 'sequence_tap',
      value: isCorrect ? 1.0 : 0.0,
      metadata: gesture,
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    if (!isCorrect || _playerSequence.length == _currentSequence.length) {
      final allCorrect = _playerSequence.length == _currentSequence.length &&
          List.generate(_currentSequence.length,
                  (i) => _playerSequence[i] == _currentSequence[i])
              .every((v) => v);

      setState(() {
        _showFeedback = true;
        _lastCorrect = allCorrect;
      });

      if (allCorrect) _correctCount++;
      else _wrongCount++;

      await Future.delayed(const Duration(milliseconds: 1000));
      _round++;
      _nextRound();
    } else {
      setState(() {});
    }
  }

  void _endGame() async {
    _sequenceTimer?.cancel();
    setState(() => _gameOver = true);

    widget.session.game3Complete = true;
    await _logger.updateSessionRisks(widget.session);

    if (mounted) {
      Navigator.pushReplacementNamed(context, '/report',
          arguments: widget.session);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              _buildHeader(),
              const SizedBox(height: 24),
              Expanded(
                child: FadeTransition(
                  opacity: _fadeCtrl,
                  child: _gameOver
                      ? _buildCompleting()
                      : _currentTaskType == 'emotion'
                          ? _buildEmotionTask()
                          : _buildSequenceTask(),
                ),
              ),
              _buildScoreBar(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Row(
          children: [
            const Text('Game 3 of 3',
                style: TextStyle(color: AppColors.textDim, fontSize: 12)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.autism.withOpacity(0.1),
                borderRadius: BorderRadius.circular(100),
              ),
              child: const Text('Autism Screen',
                  style: TextStyle(
                      color: AppColors.autism,
                      fontSize: 11,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: _round / _totalRounds,
            backgroundColor: AppColors.surface2,
            valueColor: const AlwaysStoppedAnimation(AppColors.autism),
            minHeight: 4,
          ),
        ),
        const SizedBox(height: 4),
        Text('Round ${_round + 1} / $_totalRounds',
            style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
      ],
    );
  }

  Widget _buildEmotionTask() {
    if (_currentEmotion == null) return const SizedBox();
    return Column(
      children: [
        const Text('How does this face feel?',
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.text)),
        const SizedBox(height: 8),
        const Text('اضغط على المشاعر الصحيحة',
            style: TextStyle(color: AppColors.textDim, fontSize: 13)),
        const SizedBox(height: 28),
        // Face display
        Container(
          width: 140,
          height: 140,
          decoration: BoxDecoration(
            color: AppColors.autism.withOpacity(0.08),
            shape: BoxShape.circle,
            border: Border.all(
              color: _showFeedback
                  ? (_lastCorrect ? AppColors.accent2 : AppColors.accent4)
                  : AppColors.autism.withOpacity(0.3),
              width: 2,
            ),
          ),
          child: Center(
            child: Text(
              _currentEmotion.emoji,
              style: const TextStyle(fontSize: 80),
            ),
          ),
        ),
        const SizedBox(height: 32),
        // Answer options
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          childAspectRatio: 2.8,
          children: _shuffledOptions.map((opt) {
            return GestureDetector(
              onTap: () => _onEmotionSelected(opt),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 150),
                decoration: BoxDecoration(
                  color: _showFeedback
                      ? (opt == _currentEmotion.label
                          ? AppColors.accent2.withOpacity(0.15)
                          : AppColors.surface2)
                      : AppColors.surface2,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: _showFeedback
                        ? (opt == _currentEmotion.label
                            ? AppColors.accent2
                            : AppColors.border)
                        : AppColors.border,
                  ),
                ),
                child: Center(
                  child: Text(
                    opt,
                    style: TextStyle(
                      color: _showFeedback && opt == _currentEmotion.label
                          ? AppColors.accent2
                          : AppColors.text,
                      fontWeight: FontWeight.w500,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ],
    );
  }

  Widget _buildSequenceTask() {
    return Column(
      children: [
        const Text('Copy the pattern!',
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w600, color: AppColors.text)),
        const SizedBox(height: 4),
        const Text('Watch, then repeat in the same order',
            style: TextStyle(color: AppColors.textDim, fontSize: 13)),
        const SizedBox(height: 28),
        // Show sequence being demonstrated
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(_currentSequence.length, (i) {
            final isActive = _showingSequence && i == _sequenceIndex;
            return AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              margin: const EdgeInsets.symmetric(horizontal: 6),
              width: 60,
              height: 60,
              decoration: BoxDecoration(
                color: isActive
                    ? AppColors.autism.withOpacity(0.2)
                    : AppColors.surface2,
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: isActive ? AppColors.autism : AppColors.border,
                  width: isActive ? 2 : 1,
                ),
              ),
              child: Center(
                child: Text(
                  _showingSequence ? (i <= _sequenceIndex ? _currentSequence[i] : '?') : _currentSequence[i],
                  style: const TextStyle(fontSize: 28),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 12),
        Text(
          _showingSequence ? 'Watch carefully...' : 'Now you try!',
          style: TextStyle(
            color: _showingSequence ? AppColors.textDim : AppColors.autism,
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(height: 32),
        // Player input area
        if (!_showingSequence) ...[
          const Text('Your sequence:',
              style: TextStyle(color: AppColors.textDim, fontSize: 13)),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(
              _currentSequence.length,
              (i) => Container(
                margin: const EdgeInsets.symmetric(horizontal: 6),
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  color: i < _playerSequence.length
                      ? AppColors.autism.withOpacity(0.15)
                      : AppColors.surface2,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                    color: i < _playerSequence.length
                        ? AppColors.autism
                        : AppColors.border,
                  ),
                ),
                child: Center(
                  child: Text(
                    i < _playerSequence.length ? _playerSequence[i] : '',
                    style: const TextStyle(fontSize: 24),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 24),
          // Gesture buttons
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: ['👋', '✊', '✌️'].map((g) {
              return GestureDetector(
                onTap: () => _onSequenceGestureTap(g),
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 10),
                  width: 72,
                  height: 72,
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Center(
                    child: Text(g, style: const TextStyle(fontSize: 36)),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ],
    );
  }

  Widget _buildCompleting() {
    return const Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text('🎉', style: TextStyle(fontSize: 60)),
          SizedBox(height: 16),
          Text('All games complete!',
              style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.w700,
                  color: AppColors.text)),
          SizedBox(height: 8),
          Text('Generating your report...',
              style: TextStyle(color: AppColors.textDim, fontSize: 15)),
        ],
      ),
    );
  }

  Widget _buildScoreBar() {
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          _scoreChip('✓ $_correctCount', AppColors.accent2),
          const SizedBox(width: 12),
          _scoreChip('✗ $_wrongCount', AppColors.accent4),
        ],
      ),
    );
  }

  Widget _scoreChip(String label, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(100),
      ),
      child: Text(label,
          style: TextStyle(
              color: color, fontSize: 13, fontWeight: FontWeight.w600)),
    );
  }

  @override
  void dispose() {
    _sequenceTimer?.cancel();
    _bounceCtrl.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }
}
