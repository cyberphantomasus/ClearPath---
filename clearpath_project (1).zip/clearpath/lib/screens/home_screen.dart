import 'package:flutter/material.dart';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  final _nameController = TextEditingController();
  int _selectedAge = 6;
  final _logger = LoggerService();
  final _tts = TtsService();
  List<Map<String, dynamic>> _pastSessions = [];

  late AnimationController _fadeCtrl;
  late Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _tts.init();
    _loadPastSessions();
    _fadeCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _fadeAnim = CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut);
    _fadeCtrl.forward();
  }

  Future<void> _loadPastSessions() async {
    final sessions = await _logger.getAllSessions();
    setState(() => _pastSessions = sessions.take(5).toList());
  }

  void _startSession() async {
    final name = _nameController.text.trim();
    if (name.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please enter the child\'s name'),
          backgroundColor: AppColors.accent4,
        ),
      );
      return;
    }

    final session = SessionModel(childName: name, childAge: _selectedAge);
    await _logger.saveSession(session);

    if (mounted) {
      Navigator.pushNamed(context, '/game1', arguments: session);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: FadeTransition(
        opacity: _fadeAnim,
        child: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeader(),
                const SizedBox(height: 32),
                _buildInputCard(),
                const SizedBox(height: 24),
                _buildGameOverview(),
                if (_pastSessions.isNotEmpty) ...[
                  const SizedBox(height: 24),
                  _buildPastSessions(),
                ],
                const SizedBox(height: 40),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: AppColors.accent.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(Icons.psychology_outlined,
                  color: AppColors.accent, size: 26),
            ),
            const SizedBox(width: 12),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('ClearPath',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.w700,
                      color: AppColors.accent,
                      letterSpacing: -0.5,
                    )),
                Text('كلير باث',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textDim.withOpacity(0.6),
                    )),
              ],
            ),
          ],
        ),
        const SizedBox(height: 20),
        const Text('Child Developmental\nScreening',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.w700,
              color: AppColors.text,
              height: 1.2,
              letterSpacing: -0.5,
            )),
        const SizedBox(height: 8),
        const Text(
          'Free · Offline · Arabic · 10 minutes',
          style: TextStyle(color: AppColors.textDim, fontSize: 14),
        ),
        const SizedBox(height: 4),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
          decoration: BoxDecoration(
            color: AppColors.accent2.withOpacity(0.1),
            borderRadius: BorderRadius.circular(100),
          ),
          child: const Text(
            '● No internet required',
            style: TextStyle(
              color: AppColors.accent2,
              fontSize: 11,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildInputCard() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text('Start New Screening',
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: AppColors.text,
              )),
          const SizedBox(height: 16),
          TextField(
            controller: _nameController,
            style: const TextStyle(color: AppColors.text, fontSize: 15),
            decoration: const InputDecoration(
              labelText: 'Child\'s Name',
              hintText: 'Enter child\'s name',
              prefixIcon:
                  Icon(Icons.person_outline, color: AppColors.textDim),
            ),
          ),
          const SizedBox(height: 14),
          const Text('Age',
              style: TextStyle(color: AppColors.textDim, fontSize: 13)),
          const SizedBox(height: 8),
          SizedBox(
            height: 44,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: 9, // ages 4–12
              separatorBuilder: (_, __) => const SizedBox(width: 8),
              itemBuilder: (_, i) {
                final age = i + 4;
                final selected = age == _selectedAge;
                return GestureDetector(
                  onTap: () => setState(() => _selectedAge = age),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 44,
                    height: 44,
                    decoration: BoxDecoration(
                      color: selected
                          ? AppColors.accent
                          : AppColors.surface2,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: selected ? AppColors.accent : AppColors.border,
                      ),
                    ),
                    child: Center(
                      child: Text(
                        '$age',
                        style: TextStyle(
                          color: selected ? Colors.white : AppColors.textDim,
                          fontWeight: FontWeight.w600,
                          fontSize: 15,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 20),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _startSession,
              icon: const Icon(Icons.play_arrow_rounded, size: 22),
              label: const Text('Begin Screening'),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGameOverview() {
    const games = [
      (
        icon: Icons.text_fields_rounded,
        label: 'Letter Matching',
        condition: 'Dyslexia',
        color: AppColors.dyslexia,
        desc: 'Arabic letter recognition and pattern errors',
      ),
      (
        icon: Icons.center_focus_strong_rounded,
        label: 'Focus Task',
        condition: 'ADHD',
        color: AppColors.adhd,
        desc: 'Sustained attention and impulse control',
      ),
      (
        icon: Icons.face_rounded,
        label: 'Social Patterns',
        condition: 'Autism Spectrum',
        color: AppColors.autism,
        desc: 'Emotion recognition and social response',
      ),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('3 Mini-Games · 10 Minutes',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppColors.text,
            )),
        const SizedBox(height: 12),
        ...games.map(
          (g) => Container(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: g.color.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(g.icon, color: g.color, size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(g.label,
                          style: const TextStyle(
                            fontWeight: FontWeight.w600,
                            fontSize: 14,
                            color: AppColors.text,
                          )),
                      Text(g.desc,
                          style: const TextStyle(
                            fontSize: 12,
                            color: AppColors.textDim,
                          )),
                    ],
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: g.color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(100),
                  ),
                  child: Text(
                    g.condition,
                    style: TextStyle(
                      color: g.color,
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildPastSessions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text('Recent Sessions',
            style: TextStyle(
              fontSize: 15,
              fontWeight: FontWeight.w600,
              color: AppColors.text,
            )),
        const SizedBox(height: 10),
        ..._pastSessions.map((s) {
          final date = DateTime.fromMillisecondsSinceEpoch(
              s['start_time'] as int);
          final dyslexia = ((s['dyslexia_risk'] as double?) ?? 0) * 100;
          final adhd = ((s['adhd_risk'] as double?) ?? 0) * 100;
          final autism = ((s['autism_risk'] as double?) ?? 0) * 100;
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppColors.border),
            ),
            child: Row(
              children: [
                Container(
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    color: AppColors.surface2,
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Icon(Icons.history_rounded,
                      color: AppColors.textDim, size: 18),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(s['child_name'] as String,
                          style: const TextStyle(
                              fontWeight: FontWeight.w600,
                              fontSize: 14,
                              color: AppColors.text)),
                      Text(
                          '${date.day}/${date.month}/${date.year}  ·  Age ${s['child_age']}',
                          style: const TextStyle(
                              fontSize: 11, color: AppColors.textDim)),
                    ],
                  ),
                ),
                Row(
                  children: [
                    _miniScore(
                        '${dyslexia.round()}%', AppColors.dyslexia),
                    const SizedBox(width: 4),
                    _miniScore('${adhd.round()}%', AppColors.adhd),
                    const SizedBox(width: 4),
                    _miniScore('${autism.round()}%', AppColors.autism),
                  ],
                ),
              ],
            ),
          );
        }),
      ],
    );
  }

  Widget _miniScore(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(6),
      ),
      child: Text(text,
          style: TextStyle(
              color: color, fontSize: 10, fontWeight: FontWeight.w700)),
    );
  }

  @override
  void dispose() {
    _nameController.dispose();
    _fadeCtrl.dispose();
    super.dispose();
  }
}
