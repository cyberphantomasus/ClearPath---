import 'package:flutter/material.dart';
import 'dart:async';
import 'dart:math';
import '../main.dart';
import '../models/session_model.dart';
import '../services/logger.dart';
import '../services/tts_service.dart';

/// Game 2 — Focus & Attention Task
/// Screens for ADHD by measuring:
///   - Sustained attention duration (accuracy over time)
///   - Impulsivity score (false taps before target fully appears)
///   - Distractor interference
///   - Recovery speed after distractors
///   - Response time variance (high variance = dysregulation)

class Game2Screen extends StatefulWidget {
  final SessionModel session;
  const Game2Screen({super.key, required this.session});

  @override
  State<Game2Screen> createState() => _Game2ScreenState();
}

class _Game2ScreenState extends State<Game2Screen>
    with TickerProviderStateMixin {
  final _logger = LoggerService();
  final _tts = TtsService();
  final _random = Random();

  static const _gameDurationSeconds = 180; // 3 minutes
  static const _targetAppearIntervalMs = 2000;
  static const _targetVisibleMs = 800;

  int _timeRemaining = _gameDurationSeconds;
  Timer? _gameTimer;
  Timer? _spawnTimer;
  Timer? _targetHideTimer;

  // Game state
  bool _targetVisible = false;
  bool _distractorVisible = false;
  Offset _targetPosition = const Offset(0.5, 0.5); // 0..1 normalized
  Offset _distractorPosition = const Offset(0.3, 0.3);
  DateTime? _targetAppearTime;
  bool _gameOver = false;

  // Stats
  int _correctTaps = 0;
  int _falseTaps = 0;
  int _misses = 0;
  int _distractorTaps = 0;

  // Difficulty ramp — increases over time
  double _difficultyLevel = 1.0;

  late AnimationController _pulseCtrl;

  @override
  void initState() {
    super.initState();
    _pulseCtrl = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    )..repeat(reverse: true);
    _tts.speak(TtsService.game2Intro);
    Future.delayed(const Duration(seconds: 2), _startGame);
  }

  void _startGame() {
    _startMainTimer();
    _scheduleNextTarget();
  }

  void _startMainTimer() {
    _gameTimer = Timer.periodic(const Duration(seconds: 1), (t) {
      if (_timeRemaining <= 0) {
        _endGame();
        return;
      }
      setState(() {
        _timeRemaining--;
        // Increase difficulty every 30 seconds
        _difficultyLevel = 1.0 + (_gameDurationSeconds - _timeRemaining) / 60.0;
      });
    });
  }

  void _scheduleNextTarget() {
    if (_gameOver) return;

    // Variable interval — faster with more difficulty
    final interval = (_targetAppearIntervalMs / _difficultyLevel).round();
    final jitter = _random.nextInt(800) - 400; // ±400ms randomness

    _spawnTimer = Timer(
      Duration(milliseconds: (interval + jitter).clamp(600, 3000)),
      _spawnTarget,
    );
  }

  void _spawnTarget() {
    if (_gameOver) return;

    // Randomly decide whether to show a distractor first (makes task harder)
    final showDistractorFirst = _random.nextDouble() < 0.3 * _difficultyLevel.clamp(0, 1);

    if (showDistractorFirst) {
      _showDistractor();
      Future.delayed(const Duration(milliseconds: 600), () {
        if (!_gameOver) _showTarget();
      });
    } else {
      _showTarget();
    }
  }

  void _showTarget() {
    if (_gameOver) return;
    setState(() {
      _targetVisible = true;
      _targetPosition = Offset(
        0.15 + _random.nextDouble() * 0.70,
        0.15 + _random.nextDouble() * 0.60,
      );
      _targetAppearTime = DateTime.now();
    });

    // Hide target after visible duration
    _targetHideTimer = Timer(
      Duration(milliseconds: (_targetVisibleMs / _difficultyLevel).round().clamp(400, 1000)),
      () {
        if (!_gameOver) {
          final wasVisible = _targetVisible;
          setState(() => _targetVisible = false);
          if (wasVisible) {
            // Child missed the target
            _misses++;
            final event = InteractionEvent(
                gameId: 2, actionType: 'miss', value: 0.0);
            widget.session.addEvent(event);
            _logger.logEvent(widget.session.id, event);
          }
          _scheduleNextTarget();
        }
      },
    );
  }

  void _showDistractor() {
    if (_gameOver) return;
    setState(() {
      _distractorVisible = true;
      _distractorPosition = Offset(
        0.1 + _random.nextDouble() * 0.80,
        0.1 + _random.nextDouble() * 0.70,
      );
    });
    Future.delayed(const Duration(milliseconds: 500), () {
      if (!_gameOver) setState(() => _distractorVisible = false);
    });
  }

  void _onTargetTap() async {
    if (!_targetVisible || _targetAppearTime == null) return;

    final responseTime =
        DateTime.now().difference(_targetAppearTime!).inMilliseconds.toDouble();

    _correctTaps++;
    setState(() => _targetVisible = false);
    _targetHideTimer?.cancel();

    final event = InteractionEvent(
      gameId: 2,
      actionType: 'correct',
      value: responseTime,
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);

    _tts.speak(TtsService.wellDone);
    _scheduleNextTarget();
  }

  void _onFalseTap() async {
    // Tapped background when no target visible — impulsivity signal
    if (_targetVisible) return; // valid tap area

    _falseTaps++;
    final event = InteractionEvent(
      gameId: 2,
      actionType: 'false_tap',
      value: 0.0,
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);
  }

  void _onDistractorTap() async {
    _distractorTaps++;
    setState(() => _distractorVisible = false);

    final event = InteractionEvent(
      gameId: 2,
      actionType: 'false_tap',
      value: 0.0,
      metadata: 'distractor',
    );
    widget.session.addEvent(event);
    await _logger.logEvent(widget.session.id, event);
  }

  void _endGame() async {
    _gameTimer?.cancel();
    _spawnTimer?.cancel();
    _targetHideTimer?.cancel();
    setState(() => _gameOver = true);

    widget.session.game2Complete = true;
    await _logger.updateSessionRisks(widget.session);
    await Future.delayed(const Duration(milliseconds: 1000));
    if (mounted) {
      Navigator.pushReplacementNamed(context, '/game3',
          arguments: widget.session);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(20),
              child: _buildProgressHeader(),
            ),
            Expanded(
              child: GestureDetector(
                onTapDown: (_) => _onFalseTap(),
                child: Stack(
                  children: [
                    // Background play field
                    Container(
                      margin: const EdgeInsets.symmetric(horizontal: 20),
                      decoration: BoxDecoration(
                        color: AppColors.surface,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(color: AppColors.border),
                      ),
                      child: _buildPlayField(),
                    ),
                    // Distractor
                    if (_distractorVisible)
                      _buildDistractor(),
                    // Target (tap this!)
                    if (_targetVisible)
                      _buildTarget(),
                  ],
                ),
              ),
            ),
            _buildStatsBar(),
          ],
        ),
      ),
    );
  }

  Widget _buildProgressHeader() {
    return Column(
      children: [
        Row(
          children: [
            const Text('Game 2 of 3',
                style: TextStyle(color: AppColors.textDim, fontSize: 12)),
            const Spacer(),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(
                color: AppColors.adhd.withOpacity(0.1),
                borderRadius: BorderRadius.circular(100),
              ),
              child: const Text('ADHD Screen',
                  style: TextStyle(
                      color: AppColors.adhd,
                      fontSize: 11,
                      fontWeight: FontWeight.w600)),
            ),
          ],
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: _timeRemaining / _gameDurationSeconds,
            backgroundColor: AppColors.surface2,
            valueColor: const AlwaysStoppedAnimation(AppColors.adhd),
            minHeight: 4,
          ),
        ),
        const SizedBox(height: 6),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text('${_timeRemaining}s remaining',
                style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
            Text('Difficulty: ${_difficultyLevel.toStringAsFixed(1)}x',
                style: const TextStyle(color: AppColors.textDim, fontSize: 12)),
          ],
        ),
      ],
    );
  }

  Widget _buildPlayField() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.touch_app_rounded,
            color: AppColors.textMuted.withOpacity(0.3),
            size: 48,
          ),
          const SizedBox(height: 8),
          Text(
            _targetVisible ? 'Tap the star!' : 'Watch and wait...',
            style: TextStyle(
              color: AppColors.textMuted.withOpacity(0.5),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTarget() {
    return LayoutBuilder(builder: (context, constraints) {
      final x = _targetPosition.dx * constraints.maxWidth;
      final y = _targetPosition.dy * constraints.maxHeight;
      return Positioned(
        left: x - 35,
        top: y - 35,
        child: GestureDetector(
          onTap: _onTargetTap,
          child: AnimatedBuilder(
            animation: _pulseCtrl,
            builder: (_, __) => Container(
              width: 70,
              height: 70,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColors.adhd.withOpacity(0.15 + _pulseCtrl.value * 0.1),
                border: Border.all(
                  color: AppColors.adhd,
                  width: 2 + _pulseCtrl.value * 1,
                ),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.adhd.withOpacity(0.3 + _pulseCtrl.value * 0.2),
                    blurRadius: 20 + _pulseCtrl.value * 10,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: const Icon(Icons.star_rounded,
                  color: AppColors.adhd, size: 36),
            ),
          ),
        ),
      );
    });
  }

  Widget _buildDistractor() {
    return LayoutBuilder(builder: (context, constraints) {
      final x = _distractorPosition.dx * constraints.maxWidth;
      final y = _distractorPosition.dy * constraints.maxHeight;
      return Positioned(
        left: x - 28,
        top: y - 28,
        child: GestureDetector(
          onTap: _onDistractorTap,
          child: Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: AppColors.textMuted.withOpacity(0.08),
              border: Border.all(color: AppColors.border, width: 1),
            ),
            child: const Icon(Icons.circle_outlined,
                color: AppColors.textMuted, size: 28),
          ),
        ),
      );
    });
  }

  Widget _buildStatsBar() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _stat('Hits', '$_correctTaps', AppColors.accent2),
          _stat('False Taps', '$_falseTaps', AppColors.accent4),
          _stat('Misses', '$_misses', AppColors.accent3),
        ],
      ),
    );
  }

  Widget _stat(String label, String value, Color color) {
    return Column(
      children: [
        Text(value,
            style: TextStyle(
                color: color, fontSize: 22, fontWeight: FontWeight.w700)),
        Text(label,
            style: const TextStyle(color: AppColors.textDim, fontSize: 11)),
      ],
    );
  }

  @override
  void dispose() {
    _gameTimer?.cancel();
    _spawnTimer?.cancel();
    _targetHideTimer?.cancel();
    _pulseCtrl.dispose();
    super.dispose();
  }
}
